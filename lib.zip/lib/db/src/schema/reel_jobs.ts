import { pgTable, text, serial, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const reelJobsTable = pgTable("reel_jobs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  prompt: text("prompt").notNull(),
  style: text("style").notNull(),
  musicStyle: text("music_style"),
  hasWatermark: boolean("has_watermark").notNull().default(true),
  status: text("status").notNull().default("pending"),
  progress: integer("progress").default(0),
  videoUrl: text("video_url"),
  thumbnailUrl: text("thumbnail_url"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  completedAt: timestamp("completed_at", { withTimezone: true }),
});

export const insertReelJobSchema = createInsertSchema(reelJobsTable).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});
export type InsertReelJob = z.infer<typeof insertReelJobSchema>;
export type ReelJob = typeof reelJobsTable.$inferSelect;
