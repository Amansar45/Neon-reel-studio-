import { pgTable, text, serial, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const exampleReelsTable = pgTable("example_reels", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  style: text("style").notNull(),
  thumbnailUrl: text("thumbnail_url").notNull(),
  videoUrl: text("video_url"),
  views: integer("views").notNull().default(0),
  caption: text("caption"),
});

export const insertExampleReelSchema = createInsertSchema(exampleReelsTable).omit({
  id: true,
});
export type InsertExampleReel = z.infer<typeof insertExampleReelSchema>;
export type ExampleReel = typeof exampleReelsTable.$inferSelect;
