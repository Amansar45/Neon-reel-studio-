import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Zap, Menu, X, User, LogOut, LayoutDashboard, Home, Sparkles, DollarSign } from "lucide-react";
import { useGetMe, useLogout, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

export function Navbar() {
  const [location, setLocation] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const queryClient = useQueryClient();

  const token = typeof window !== "undefined" ? localStorage.getItem("rf_token") : null;
  const { data: user } = useGetMe({ query: { enabled: !!token, queryKey: getGetMeQueryKey() } });
  const logoutMutation = useLogout();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 16);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);

  function handleLogout() {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        localStorage.removeItem("rf_token");
        queryClient.clear();
        setLocation("/");
        setMobileOpen(false);
      },
    });
  }

  const navLinks = [
    { href: "/", label: "Home", icon: Home },
    { href: "/generate", label: "Generate", icon: Sparkles },
    { href: "/pricing", label: "Pricing", icon: DollarSign },
    ...(user ? [{ href: "/dashboard", label: "Dashboard", icon: LayoutDashboard }] : []),
  ];

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? "border-b border-white/8 bg-background/92 backdrop-blur-2xl shadow-[0_8px_32px_rgba(0,0,0,0.4)]"
            : "border-b border-transparent bg-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">

            {/* Logo */}
            <Link href="/">
              <motion.div
                className="flex items-center gap-2.5 cursor-pointer"
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                transition={{ duration: 0.18 }}
                data-testid="link-logo"
                onClick={() => setMobileOpen(false)}
              >
                <motion.div
                  className="w-8 h-8 rounded-xl bg-primary/20 border border-primary/40 flex items-center justify-center"
                  animate={{ boxShadow: ["0 0 8px hsl(270 100% 63% / 0.2)", "0 0 18px hsl(270 100% 63% / 0.5)", "0 0 8px hsl(270 100% 63% / 0.2)"] }}
                  transition={{ repeat: Infinity, duration: 2.5, ease: "easeInOut" }}
                >
                  <Zap className="w-4 h-4 text-primary" fill="currentColor" />
                </motion.div>
                <span className="font-black text-lg tracking-tight gradient-text">ReelForge</span>
              </motion.div>
            </Link>

            {/* Desktop nav */}
            <div className="hidden md:flex items-center gap-0.5">
              {navLinks.map((link) => {
                const isActive = location === link.href;
                return (
                  <Link key={link.href} href={link.href}>
                    <span
                      className={`relative px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 cursor-pointer group ${
                        isActive
                          ? "text-primary"
                          : "text-muted-foreground hover:text-foreground hover:bg-white/6"
                      }`}
                      data-testid={`link-nav-${link.label.toLowerCase()}`}
                    >
                      {/* Active pill background */}
                      {isActive && (
                        <motion.span
                          layoutId="nav-active-pill"
                          className="absolute inset-0 rounded-xl bg-primary/12"
                          transition={{ type: "spring", duration: 0.4, bounce: 0.2 }}
                        />
                      )}
                      {/* Label */}
                      <span className="relative z-10">{link.label}</span>
                      {/* Active bottom line */}
                      {isActive && (
                        <motion.span
                          layoutId="nav-active-line"
                          className="absolute bottom-0.5 left-1/2 -translate-x-1/2 w-4 h-0.5 rounded-full bg-primary"
                          transition={{ type: "spring", duration: 0.4, bounce: 0.2 }}
                        />
                      )}
                    </span>
                  </Link>
                );
              })}
            </div>

            {/* Desktop auth */}
            <div className="hidden md:flex items-center gap-3">
              {user ? (
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 hover:bg-white/8 transition-all">
                    <User className="w-3.5 h-3.5 text-primary" />
                    <span className="text-sm text-foreground font-medium">{user.name}</span>
                    <span className={`text-xs px-1.5 py-0.5 rounded-md font-bold tracking-wide ${
                      user.plan === "ultra" ? "bg-yellow-500/20 text-yellow-400" :
                      user.plan === "pro"   ? "bg-primary/20 text-primary" :
                                             "bg-muted text-muted-foreground"
                    }`}>{user.plan.toUpperCase()}</span>
                  </div>
                  <motion.button
                    onClick={handleLogout}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="p-2 rounded-xl text-muted-foreground hover:text-foreground hover:bg-white/6 transition-colors touch-target"
                    data-testid="button-logout"
                    title="Log out"
                  >
                    <LogOut className="w-4 h-4" />
                  </motion.button>
                </div>
              ) : (
                <>
                  <Link href="/login">
                    <motion.span
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.97 }}
                      className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors cursor-pointer block"
                      data-testid="link-login"
                    >
                      Log in
                    </motion.span>
                  </Link>
                  <Link href="/register">
                    <motion.span
                      whileHover={{ scale: 1.04, y: -1 }}
                      whileTap={{ scale: 0.96 }}
                      transition={{ duration: 0.15 }}
                      className="relative px-4 py-2 text-sm bg-primary text-primary-foreground rounded-xl font-semibold neon-glow cursor-pointer overflow-hidden block group"
                      data-testid="link-signup"
                    >
                      <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full bg-gradient-to-r from-transparent via-white/15 to-transparent transition-transform duration-500" />
                      <span className="relative z-10">Get Started</span>
                    </motion.span>
                  </Link>
                </>
              )}
            </div>

            {/* Mobile toggle */}
            <button
              className="md:hidden w-10 h-10 flex items-center justify-center rounded-xl hover:bg-white/6 transition-all active:scale-95"
              onClick={() => setMobileOpen(!mobileOpen)}
              data-testid="button-mobile-menu"
              aria-label="Toggle menu"
            >
              <AnimatePresence mode="wait" initial={false}>
                {mobileOpen ? (
                  <motion.div key="x" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }} transition={{ duration: 0.15 }}>
                    <X className="w-5 h-5" />
                  </motion.div>
                ) : (
                  <motion.div key="menu" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }} transition={{ duration: 0.15 }}>
                    <Menu className="w-5 h-5" />
                  </motion.div>
                )}
              </AnimatePresence>
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile full-screen drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              key="backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm md:hidden"
              onClick={() => setMobileOpen(false)}
            />
            <motion.div
              key="drawer"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 28, stiffness: 280 }}
              className="fixed top-0 right-0 bottom-0 z-50 w-[80vw] max-w-sm md:hidden flex flex-col bg-background/98 backdrop-blur-3xl border-l border-white/8"
            >
              {/* Drawer header */}
              <div className="flex items-center justify-between px-6 py-5 border-b border-white/6">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-primary/20 border border-primary/40 flex items-center justify-center">
                    <Zap className="w-3.5 h-3.5 text-primary" fill="currentColor" />
                  </div>
                  <span className="font-black text-base gradient-text">ReelForge</span>
                </div>
                <button
                  onClick={() => setMobileOpen(false)}
                  className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/6 transition-all"
                >
                  <X className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>

              {/* Nav links */}
              <div className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
                {navLinks.map((link, i) => {
                  const isActive = location === link.href;
                  return (
                    <motion.div
                      key={link.href}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05 + 0.05 }}
                    >
                      <Link href={link.href}>
                        <div
                          onClick={() => setMobileOpen(false)}
                          className={`flex items-center gap-3.5 px-4 py-3.5 rounded-2xl cursor-pointer transition-all active:scale-98 ${
                            isActive
                              ? "bg-primary/15 border border-primary/25 text-primary"
                              : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                          }`}
                        >
                          <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${isActive ? "bg-primary/20" : "bg-white/5"}`}>
                            <link.icon className="w-4 h-4" />
                          </div>
                          <span className="font-semibold text-[15px]">{link.label}</span>
                          {isActive && (
                            <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary" />
                          )}
                        </div>
                      </Link>
                    </motion.div>
                  );
                })}
              </div>

              {/* Drawer footer */}
              <div className="px-4 pb-8 space-y-3 border-t border-white/6 pt-4">
                {user ? (
                  <>
                    <div className="flex items-center gap-3 px-4 py-3 rounded-2xl bg-white/4 border border-white/8">
                      <div className="w-9 h-9 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center">
                        <User className="w-4 h-4 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold truncate">{user.name}</p>
                        <p className="text-xs text-muted-foreground">{user.email}</p>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-lg font-bold ${
                        user.plan === "ultra" ? "bg-yellow-500/20 text-yellow-400" :
                        user.plan === "pro"   ? "bg-primary/20 text-primary" :
                                               "bg-muted text-muted-foreground"
                      }`}>{user.plan.toUpperCase()}</span>
                    </div>
                    <button
                      onClick={handleLogout}
                      className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-muted-foreground hover:text-foreground hover:bg-white/5 transition-all text-sm font-medium"
                    >
                      <LogOut className="w-4 h-4" />
                      Log out
                    </button>
                  </>
                ) : (
                  <>
                    <Link href="/login">
                      <div
                        onClick={() => setMobileOpen(false)}
                        className="w-full py-3.5 rounded-2xl text-center text-sm font-semibold text-muted-foreground border border-white/10 hover:bg-white/4 transition-all cursor-pointer active:scale-98"
                      >
                        Log in
                      </div>
                    </Link>
                    <Link href="/register">
                      <div
                        onClick={() => setMobileOpen(false)}
                        className="w-full py-3.5 rounded-2xl text-center text-sm font-bold bg-primary text-white neon-glow-sm hover:bg-primary/90 transition-all cursor-pointer active:scale-98"
                      >
                        Get Started Free
                      </div>
                    </Link>
                  </>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
