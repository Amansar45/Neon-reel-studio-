import { useRef, useState, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Upload, X, ImageIcon, AlertCircle, CloudUpload } from "lucide-react";

// ── Constants ──────────────────────────────────────────────────────────────────
const MAX_FILES = 5;
const MAX_BYTES = 10 * 1024 * 1024; // 10 MB
const ACCEPTED  = ["image/jpeg", "image/png", "image/webp", "image/gif"];

// ── Helpers ────────────────────────────────────────────────────────────────────
function formatBytes(n: number) {
  if (n < 1024)       return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

function validateFiles(incoming: File[], existing: File[]): { valid: File[]; error: string | null } {
  const valid: File[] = [];
  let error: string | null = null;

  for (const f of incoming) {
    if (!ACCEPTED.includes(f.type)) {
      error = `"${f.name}" isn't a supported image format (PNG, JPG, WebP, GIF).`;
      continue;
    }
    if (f.size > MAX_BYTES) {
      error = `"${f.name}" is too large — max 10 MB per image.`;
      continue;
    }
    if (existing.length + valid.length >= MAX_FILES) {
      error = `You can upload up to ${MAX_FILES} images.`;
      break;
    }
    valid.push(f);
  }
  return { valid, error };
}

// ── Image thumbnail card ───────────────────────────────────────────────────────
function ImageCard({
  file,
  index,
  onRemove,
}: {
  file: File;
  index: number;
  onRemove: (i: number) => void;
}) {
  const [src, setSrc] = useState<string | null>(null);

  useEffect(() => {
    const url = URL.createObjectURL(file);
    setSrc(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.7 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.6 }}
      transition={{ type: "spring", stiffness: 400, damping: 28 }}
      className="relative group flex-shrink-0"
      data-testid={`image-card-${index}`}
    >
      {/* Thumbnail */}
      <div className="w-[72px] h-[72px] sm:w-20 sm:h-20 rounded-xl overflow-hidden border border-white/10 bg-white/5">
        {src ? (
          <img src={src} alt={file.name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <ImageIcon className="w-5 h-5 text-muted-foreground/40" />
          </div>
        )}
      </div>

      {/* Hover overlay with file info */}
      <div className="absolute inset-0 rounded-xl bg-black/60 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-opacity duration-150 flex flex-col items-center justify-center p-1.5 pointer-events-none">
        <p className="text-[8px] sm:text-[9px] text-white font-medium text-center leading-tight line-clamp-2 break-all">{file.name}</p>
        <p className="text-[8px] text-white/50 mt-0.5">{formatBytes(file.size)}</p>
      </div>

      {/* Remove button — visible on hover (desktop) + always on mobile touch targets */}
      <button
        onClick={() => onRemove(index)}
        aria-label="Remove image"
        className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-destructive text-white flex items-center justify-center shadow-lg sm:opacity-0 sm:group-hover:opacity-100 transition-opacity duration-150 hover:bg-red-400 active:scale-90 z-10"
        data-testid={`remove-image-${index}`}
      >
        <X className="w-2.5 h-2.5" />
      </button>

      {/* Slot number */}
      <div className="absolute -bottom-1.5 -left-1 text-[8px] text-muted-foreground/40 font-bold tabular-nums">
        {index + 1}
      </div>
    </motion.div>
  );
}

// ── Empty slot ─────────────────────────────────────────────────────────────────
function EmptySlot({ index }: { index: number }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="w-[72px] h-[72px] sm:w-20 sm:h-20 rounded-xl border border-dashed border-white/12 bg-white/[0.02] flex items-center justify-center shrink-0"
    >
      <span className="text-[10px] text-muted-foreground/25 font-bold">{index + 1}</span>
    </motion.div>
  );
}

// ── Main component ─────────────────────────────────────────────────────────────
export interface ImageUploadZoneProps {
  files: File[];
  onChange: (files: File[]) => void;
  /** When true (page-level drag detected) the zone highlights itself */
  pageIsDragging?: boolean;
}

export function ImageUploadZone({ files, onChange, pageIsDragging = false }: ImageUploadZoneProps) {
  const inputRef   = useRef<HTMLInputElement>(null);
  const [zoneDrag, setZoneDrag]   = useState(false);
  const [error,    setError]      = useState<string | null>(null);
  const [shake,    setShake]      = useState(false);

  const isDragging = zoneDrag || pageIsDragging;

  const addFiles = useCallback(
    (incoming: FileList | File[]) => {
      const arr = Array.from(incoming);
      const { valid, error: err } = validateFiles(arr, files);
      if (err) {
        setError(err);
        setShake(true);
        setTimeout(() => setShake(false), 600);
      } else {
        setError(null);
      }
      if (valid.length) onChange([...files, ...valid]);
    },
    [files, onChange]
  );

  const removeFile = useCallback(
    (idx: number) => onChange(files.filter((_, i) => i !== idx)),
    [files, onChange]
  );

  // Auto-clear error
  useEffect(() => {
    if (!error) return;
    const t = setTimeout(() => setError(null), 4000);
    return () => clearTimeout(t);
  }, [error]);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setZoneDrag(false);
      addFiles(e.dataTransfer.files);
    },
    [addFiles]
  );

  const slotsLeft = MAX_FILES - files.length;
  const canAdd    = slotsLeft > 0;

  return (
    <div className="space-y-3">
      {/* Drop zone */}
      <motion.div
        animate={shake ? { x: [-6, 6, -4, 4, 0] } : {}}
        transition={{ duration: 0.35 }}
        onDragOver={(e) => { e.preventDefault(); setZoneDrag(true); }}
        onDragEnter={(e) => { e.preventDefault(); setZoneDrag(true); }}
        onDragLeave={(e) => {
          // only fire if we're truly leaving the zone (not entering a child)
          if (!e.currentTarget.contains(e.relatedTarget as Node)) setZoneDrag(false);
        }}
        onDrop={handleDrop}
        onClick={() => canAdd && inputRef.current?.click()}
        role="button"
        aria-label="Upload images"
        tabIndex={0}
        onKeyDown={(e) => e.key === "Enter" && canAdd && inputRef.current?.click()}
        data-testid="dropzone-images"
        className={`
          relative rounded-2xl border-2 border-dashed p-5 sm:p-7
          text-center cursor-pointer
          transition-all duration-200
          focus:outline-none focus-visible:ring-2 focus-visible:ring-primary
          ${!canAdd ? "opacity-50 pointer-events-none" : ""}
          ${isDragging
            ? "border-primary bg-primary/8 scale-[1.01]"
            : "border-white/10 hover:border-primary/35 hover:bg-white/[0.025]"
          }
        `}
      >
        {/* Animated dashed border glow when dragging */}
        {isDragging && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 rounded-2xl pointer-events-none"
            style={{ boxShadow: "0 0 0 2px var(--color-primary), 0 0 24px 0 color-mix(in srgb, var(--color-primary) 30%, transparent)" }}
          />
        )}

        {/* Cloud icon */}
        <motion.div
          animate={isDragging ? { y: [-3, 0, -3], scale: 1.15 } : { y: 0, scale: 1 }}
          transition={isDragging ? { repeat: Infinity, duration: 1.2, ease: "easeInOut" } : {}}
          className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-primary/10 border border-primary/20 mb-3"
        >
          <CloudUpload className={`w-6 h-6 transition-colors ${isDragging ? "text-primary" : "text-muted-foreground"}`} />
        </motion.div>

        {isDragging ? (
          <motion.p
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-sm font-bold text-primary"
          >
            Drop to add {slotsLeft === 1 ? "image" : "images"}
          </motion.p>
        ) : (
          <>
            <p className="text-sm text-foreground font-medium">
              <span className="text-primary font-semibold">Browse files</span>
              {" "}or drag & drop here
            </p>
            <p className="text-xs text-muted-foreground/60 mt-1">
              PNG · JPG · WebP · GIF · max 10 MB · up to {MAX_FILES}
            </p>
            {canAdd && (
              <p className="text-[10px] text-muted-foreground/40 mt-2">
                {slotsLeft} slot{slotsLeft !== 1 ? "s" : ""} remaining
              </p>
            )}
          </>
        )}

        <input
          ref={inputRef}
          type="file"
          accept={ACCEPTED.join(",")}
          multiple
          className="hidden"
          onChange={(e) => { addFiles(e.target.files ?? []); e.target.value = ""; }}
          data-testid="input-file-upload"
        />
      </motion.div>

      {/* Validation error */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -6, height: 0 }}
            animate={{ opacity: 1, y: 0, height: "auto" }}
            exit={{ opacity: 0, y: -4, height: 0 }}
            transition={{ duration: 0.2 }}
            className="flex items-start gap-2 px-3 py-2.5 rounded-xl bg-destructive/10 border border-destructive/25"
          >
            <AlertCircle className="w-3.5 h-3.5 text-destructive shrink-0 mt-0.5" />
            <p className="text-xs text-destructive leading-snug">{error}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Thumbnail grid — shows filled slots + empty slot placeholders */}
      <motion.div layout className="flex flex-wrap gap-2.5">
        {files.map((f, i) => (
          <ImageCard key={`${f.name}-${f.size}-${i}`} file={f} index={i} onRemove={removeFile} />
        ))}
        {/* Empty slot ghosts */}
        {canAdd && Array.from({ length: Math.min(slotsLeft, 5 - files.length) }).map((_, i) => (
          <EmptySlot key={`empty-${i}`} index={files.length + i} />
        ))}
      </motion.div>

      {/* File list summary when files exist */}
      {files.length > 0 && (
        <motion.div
          layout
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex items-center justify-between"
        >
          <div className="flex items-center gap-1.5">
            <Upload className="w-3 h-3 text-primary" />
            <span className="text-xs text-muted-foreground">
              {files.length} image{files.length !== 1 ? "s" : ""} ready
            </span>
          </div>
          <button
            onClick={() => onChange([])}
            className="text-[10px] text-muted-foreground/50 hover:text-destructive transition-colors"
            data-testid="clear-all-images"
          >
            Clear all
          </button>
        </motion.div>
      )}
    </div>
  );
}
