import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";

// ── Types ──────────────────────────────────────────────────────────────────────
interface CaptionTheme {
  wordColor: string;
  highlightColor: string;
  highlightBg: string;
  strokeColor: string;
  fontClass: string;
  caseClass: string;
}

const THEMES: Record<string, CaptionTheme> = {
  sigma: {
    wordColor:      "text-white",
    highlightColor: "text-[#FFD600]",
    highlightBg:    "bg-[#FFD600]",
    strokeColor:    "#000",
    fontClass:      "font-black",
    caseClass:      "uppercase",
  },
  anime_motivation: {
    wordColor:      "text-white",
    highlightColor: "text-[#FF5722]",
    highlightBg:    "bg-[#FF5722]",
    strokeColor:    "#1a0000",
    fontClass:      "font-black",
    caseClass:      "uppercase",
  },
  sad_aesthetic: {
    wordColor:      "text-white/90",
    highlightColor: "text-[#A78BFA]",
    highlightBg:    "bg-[#A78BFA]",
    strokeColor:    "#0a0010",
    fontClass:      "font-bold",
    caseClass:      "normal-case",
  },
};

// ── Caption segment splitter ───────────────────────────────────────────────────
function splitIntoSegments(text: string, wordsPerSegment = 3): string[][] {
  const words = text.trim().split(/\s+/).filter(Boolean);
  const segments: string[][] = [];
  for (let i = 0; i < words.length; i += wordsPerSegment) {
    segments.push(words.slice(i, i + wordsPerSegment));
  }
  return segments.length ? segments : [["ReelForge"]];
}

// Decide which word in a segment gets the highlight color (last "power word")
function isHighlightWord(word: string, idx: number, total: number): boolean {
  if (total === 1) return true;
  // Highlight the last word, or any ALLCAPS word
  if (idx === total - 1) return true;
  if (word === word.toUpperCase() && word.length > 2) return true;
  return false;
}

// ── Word animation variants ────────────────────────────────────────────────────
const wordVariants = {
  hidden: { opacity: 0, scale: 0.4, y: 10, filter: "blur(4px)" },
  visible: (i: number) => ({
    opacity: 1,
    scale: 1,
    y: 0,
    filter: "blur(0px)",
    transition: { delay: i * 0.09, duration: 0.18, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] },
  }),
  exit: { opacity: 0, scale: 0.85, filter: "blur(3px)", transition: { duration: 0.15 } },
};

// ── Sub-component: one caption segment ────────────────────────────────────────
function CaptionSegment({ words, theme, style }: { words: string[]; theme: CaptionTheme; style: string }) {
  const isBox = style === "anime_motivation";

  return (
    <motion.div
      key={words.join("-")}
      initial="hidden"
      animate="visible"
      exit="exit"
      className="flex flex-wrap justify-center gap-x-[3px] gap-y-[2px]"
    >
      {words.map((word, i) => {
        const highlight = isHighlightWord(word, i, words.length);

        if (isBox && highlight) {
          // Anime style: colored background box around highlight word
          return (
            <motion.span
              key={i}
              custom={i}
              variants={wordVariants}
              className={`
                inline-flex items-center px-[4px] py-[1px] rounded-[3px]
                ${theme.highlightBg} text-black
                text-[13px] leading-none tracking-tight
                ${theme.fontClass} ${theme.caseClass}
              `}
              style={{ textShadow: "none" }}
            >
              {word}
            </motion.span>
          );
        }

        return (
          <motion.span
            key={i}
            custom={i}
            variants={wordVariants}
            className={`
              inline-block text-[13px] leading-none tracking-tight
              ${highlight ? theme.highlightColor : theme.wordColor}
              ${theme.fontClass} ${theme.caseClass}
            `}
            style={{
              textShadow: `
                -1px -1px 0 ${theme.strokeColor},
                 1px -1px 0 ${theme.strokeColor},
                -1px  1px 0 ${theme.strokeColor},
                 1px  1px 0 ${theme.strokeColor},
                 0   2px 8px rgba(0,0,0,0.9)
              `,
            }}
          >
            {word}
          </motion.span>
        );
      })}
    </motion.div>
  );
}

// ── Main component ─────────────────────────────────────────────────────────────
interface CaptionOverlayProps {
  prompt: string;
  style: string;
  playing?: boolean;
}

export function CaptionOverlay({ prompt, style, playing = true }: CaptionOverlayProps) {
  const theme = THEMES[style] ?? THEMES["sigma"];
  const segments = splitIntoSegments(prompt, 3);

  const [segIdx, setSegIdx] = useState(0);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!playing) return;
    const seg = segments[segIdx];
    // Duration: ~450ms per word, min 1.2s, max 2.8s
    const duration = Math.min(2800, Math.max(1200, seg.length * 550));

    timerRef.current = setTimeout(() => {
      setSegIdx((prev) => (prev + 1) % segments.length);
    }, duration);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [segIdx, playing, segments.length]);

  // Reset when prompt changes
  useEffect(() => {
    setSegIdx(0);
  }, [prompt]);

  return (
    <div className="absolute inset-x-0 bottom-[18%] flex flex-col items-center px-3 pointer-events-none">
      <AnimatePresence mode="wait">
        <CaptionSegment
          key={`${segIdx}-${segments[segIdx]?.join("")}`}
          words={segments[segIdx] ?? []}
          theme={theme}
          style={style}
        />
      </AnimatePresence>
    </div>
  );
}
