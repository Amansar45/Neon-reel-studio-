import { Link } from "wouter";
import { Zap } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-white/5 bg-background py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-primary/20 border border-primary/40 flex items-center justify-center">
                <Zap className="w-3.5 h-3.5 text-primary" />
              </div>
              <span className="font-bold gradient-text">ReelForge</span>
            </div>
            <p className="text-sm text-muted-foreground max-w-xs">
              Turn any idea into a cinematic short video. Built for creators who move fast.
            </p>
          </div>

          <div className="flex flex-wrap gap-8 text-sm text-muted-foreground">
            <div className="flex flex-col gap-2">
              <span className="font-medium text-foreground/60 uppercase text-xs tracking-wider">Product</span>
              <Link href="/generate"><span className="hover:text-primary transition-colors cursor-pointer">Generate</span></Link>
              <Link href="/pricing"><span className="hover:text-primary transition-colors cursor-pointer">Pricing</span></Link>
            </div>
            <div className="flex flex-col gap-2">
              <span className="font-medium text-foreground/60 uppercase text-xs tracking-wider">Account</span>
              <Link href="/login"><span className="hover:text-primary transition-colors cursor-pointer">Log In</span></Link>
              <Link href="/register"><span className="hover:text-primary transition-colors cursor-pointer">Sign Up</span></Link>
            </div>
          </div>
        </div>
        <div className="mt-8 pt-6 border-t border-white/5 text-sm text-muted-foreground">
          &copy; {new Date().getFullYear()} ReelForge. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
