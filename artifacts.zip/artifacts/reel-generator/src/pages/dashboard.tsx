import { motion } from "framer-motion";
import { Link } from "wouter";
import { Zap, Film, CreditCard, TrendingUp, Clock, CheckCircle, Loader2, AlertCircle, Plus } from "lucide-react";
import { useGetDashboard, useGetMe } from "@workspace/api-client-react";

const containerVariants = {
  hidden:  { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.07 } },
};
const itemVariants = {
  hidden:  { opacity: 0, y: 14 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4 } },
};

const STYLE_COLORS: Record<string, string> = {
  sigma:            "bg-slate-500/15 text-slate-300 border-slate-500/30",
  anime_motivation: "bg-pink-500/15 text-pink-300 border-pink-500/30",
  sad_aesthetic:    "bg-blue-500/15 text-blue-300 border-blue-500/30",
};
const STYLE_LABELS: Record<string, string> = {
  sigma:            "Sigma",
  anime_motivation: "Anime Motivation",
  sad_aesthetic:    "Sad Aesthetic",
};
const STYLE_BAR_COLORS: Record<string, string> = {
  sigma:            "bg-slate-400",
  anime_motivation: "bg-pink-500",
  sad_aesthetic:    "bg-blue-400",
};

const STATUS_ICONS: Record<string, React.ReactNode> = {
  completed: <CheckCircle className="w-4 h-4 text-green-400" />,
  processing: <Loader2 className="w-4 h-4 text-primary animate-spin" />,
  pending:   <Clock className="w-4 h-4 text-yellow-400" />,
  failed:    <AlertCircle className="w-4 h-4 text-red-400" />,
};
const STATUS_COLORS: Record<string, string> = {
  completed: "text-green-400",
  processing: "text-primary",
  pending:   "text-yellow-400",
  failed:    "text-red-400",
};

function formatTime(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

export default function DashboardPage() {
  const { data: dashboard, isLoading } = useGetDashboard();
  const { data: user } = useGetMe();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background pt-16 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
          <p className="text-sm text-muted-foreground">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background pt-16 flex items-center justify-center px-4">
        <div className="text-center glass-card-elevated rounded-3xl p-10 max-w-sm w-full">
          <div className="w-14 h-14 rounded-2xl bg-primary/15 border border-primary/30 flex items-center justify-center mx-auto mb-5">
            <Zap className="w-7 h-7 text-primary" fill="currentColor" />
          </div>
          <p className="text-foreground font-bold text-lg mb-1">Sign in required</p>
          <p className="text-muted-foreground text-sm mb-6">Please log in to view your dashboard.</p>
          <Link href="/login">
            <span className="block w-full py-3.5 bg-primary text-primary-foreground rounded-2xl font-bold text-sm cursor-pointer neon-glow-sm text-center">
              Log In
            </span>
          </Link>
        </div>
      </div>
    );
  }

  const planColors: Record<string, string> = {
    free:  "text-muted-foreground bg-white/6 border border-white/10",
    pro:   "text-primary bg-primary/15 border border-primary/30",
    ultra: "text-yellow-400 bg-yellow-500/15 border border-yellow-500/30",
  };
  const creditsTotal = (dashboard?.creditsRemaining ?? 0) + (dashboard?.creditsUsed ?? 0);
  const creditsPct   = creditsTotal ? Math.min(100, ((dashboard?.creditsRemaining ?? 0) / creditsTotal) * 100) : 0;

  return (
    <div className="min-h-screen bg-background pt-16">
      {/* Subtle bg orb */}
      <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[min(600px,100vw)] h-[200px] bg-primary/4 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 sm:pt-12 pb-16">

        {/* ── Header ──────────────────────────── */}
        <motion.div
          initial={{ opacity: 0, y: -14 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-start sm:items-center justify-between gap-4 mb-8 sm:mb-10"
        >
          <div>
            <h1 className="text-2xl sm:text-3xl font-black gradient-text">Dashboard</h1>
            <p className="text-muted-foreground text-sm mt-0.5">Welcome back, <span className="text-foreground font-medium">{user.name}</span></p>
          </div>
          <Link href="/generate">
            <span
              className="flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-2xl font-bold text-sm neon-glow-sm hover:bg-primary/90 transition-all cursor-pointer shrink-0 active:scale-95"
              data-testid="button-create-reel"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Create Reel</span>
              <span className="sm:hidden">Create</span>
            </span>
          </Link>
        </motion.div>

        {/* ── Stat cards ──────────────────────── */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 mb-5 sm:mb-6"
        >
          {/* Total Reels */}
          <motion.div
            variants={itemVariants}
            className="glass-card-elevated rounded-2xl sm:rounded-3xl p-5 sm:p-6 flex items-center sm:block gap-4"
            data-testid="stat-total-reels"
          >
            <div className="w-11 h-11 rounded-2xl bg-primary/12 border border-primary/25 flex items-center justify-center shrink-0">
              <Film className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground font-medium sm:mt-4 sm:mb-1">Total Reels</p>
              <p className="text-3xl sm:text-4xl font-black gradient-text">{dashboard?.totalReels ?? 0}</p>
            </div>
          </motion.div>

          {/* Credits */}
          <motion.div
            variants={itemVariants}
            className="glass-card-elevated rounded-2xl sm:rounded-3xl p-5 sm:p-6"
            data-testid="stat-credits"
          >
            <div className="flex items-center gap-3 sm:block">
              <div className="w-11 h-11 rounded-2xl bg-accent/12 border border-accent/25 flex items-center justify-center shrink-0">
                <CreditCard className="w-5 h-5 text-accent" />
              </div>
              <div className="flex-1 sm:mt-4 sm:mb-2">
                <p className="text-xs text-muted-foreground font-medium sm:mb-1">Credits Left</p>
                <p className="text-3xl sm:text-4xl font-black" style={{ color: "hsl(var(--accent))" }}>
                  {dashboard?.creditsRemaining ?? user.creditsRemaining}
                </p>
              </div>
            </div>
            <div className="mt-3 w-full h-1.5 rounded-full bg-white/8">
              <motion.div
                className="h-full rounded-full bg-accent"
                initial={{ width: 0 }}
                animate={{ width: `${creditsPct}%` }}
                transition={{ duration: 1, delay: 0.35 }}
              />
            </div>
          </motion.div>

          {/* Plan */}
          <motion.div
            variants={itemVariants}
            className="glass-card-elevated rounded-2xl sm:rounded-3xl p-5 sm:p-6 flex items-center sm:block gap-4"
            data-testid="stat-plan"
          >
            <div className="w-11 h-11 rounded-2xl bg-chart-1/12 border border-chart-1/25 flex items-center justify-center shrink-0">
              <TrendingUp className="w-5 h-5" style={{ color: "hsl(var(--chart-1))" }} />
            </div>
            <div>
              <p className="text-xs text-muted-foreground font-medium sm:mt-4 sm:mb-2">Your Plan</p>
              <div className="flex items-center gap-2 flex-wrap">
                <span className={`px-3 py-1 rounded-xl text-xs font-black uppercase tracking-wider ${planColors[user.plan] ?? "text-muted-foreground"}`}>
                  {user.plan}
                </span>
                {user.plan === "free" && (
                  <Link href="/pricing">
                    <span className="text-xs text-primary hover:text-primary/80 transition-colors cursor-pointer font-semibold">
                      Upgrade →
                    </span>
                  </Link>
                )}
              </div>
            </div>
          </motion.div>
        </motion.div>

        {/* ── Style breakdown ──────────────────── */}
        {dashboard?.styleBreakdown && dashboard.styleBreakdown.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.28 }}
            className="glass-card-elevated rounded-2xl sm:rounded-3xl p-5 sm:p-6 mb-5 sm:mb-6"
          >
            <h2 className="text-base font-bold mb-4">Style Breakdown</h2>
            <div className="space-y-3">
              {dashboard.styleBreakdown.map((s) => {
                const pct = Math.round((s.count / (dashboard.totalReels || 1)) * 100);
                return (
                  <div key={s.style} className="flex items-center gap-3">
                    <span className={`shrink-0 px-2.5 py-1 rounded-xl text-xs font-semibold border ${STYLE_COLORS[s.style] ?? "bg-muted text-muted-foreground border-muted"}`}>
                      {STYLE_LABELS[s.style] ?? s.style}
                    </span>
                    <div className="flex-1 h-2 rounded-full bg-white/6">
                      <motion.div
                        className={`h-full rounded-full ${STYLE_BAR_COLORS[s.style] ?? "bg-primary"}`}
                        initial={{ width: 0 }}
                        animate={{ width: `${pct}%` }}
                        transition={{ duration: 0.8, delay: 0.4 }}
                      />
                    </div>
                    <span className="text-xs text-muted-foreground tabular-nums w-16 text-right shrink-0">
                      {s.count} <span className="text-muted-foreground/50">({pct}%)</span>
                    </span>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* ── Recent Reels ─────────────────────── */}
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.36 }}
          className="glass-card-elevated rounded-2xl sm:rounded-3xl p-5 sm:p-6"
        >
          <h2 className="text-base font-bold mb-4">Recent Reels</h2>

          {!dashboard?.recentReels || dashboard.recentReels.length === 0 ? (
            <div className="py-12 text-center">
              <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/8 flex items-center justify-center mx-auto mb-4">
                <Film className="w-7 h-7 text-muted-foreground/40" />
              </div>
              <p className="text-muted-foreground text-sm mb-5">No reels yet. Create your first one!</p>
              <Link href="/generate">
                <span className="inline-flex items-center gap-2 px-5 py-3 bg-primary/15 text-primary rounded-2xl text-sm font-bold cursor-pointer hover:bg-primary/25 transition-all border border-primary/25">
                  <Zap className="w-4 h-4" fill="currentColor" />
                  Generate Now
                </span>
              </Link>
            </div>
          ) : (
            <div className="space-y-2 sm:space-y-3">
              {dashboard.recentReels.map((reel) => (
                <div
                  key={reel.id}
                  className="flex items-center gap-3 sm:gap-4 p-3 sm:p-4 rounded-2xl bg-white/3 hover:bg-white/5 border border-white/5 hover:border-white/10 transition-all"
                  data-testid={`reel-row-${reel.id}`}
                >
                  {reel.thumbnailUrl ? (
                    <img
                      src={reel.thumbnailUrl}
                      alt=""
                      className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl object-cover border border-white/10 shrink-0"
                    />
                  ) : (
                    <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-white/5 border border-white/8 flex items-center justify-center shrink-0">
                      <Film className="w-5 h-5 text-muted-foreground" />
                    </div>
                  )}

                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate leading-snug">{reel.prompt}</p>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <span className={`px-2 py-0.5 rounded-lg text-[10px] sm:text-xs border font-medium ${STYLE_COLORS[reel.style] ?? "bg-muted text-muted-foreground border-muted"}`}>
                        {STYLE_LABELS[reel.style] ?? reel.style}
                      </span>
                      <span className="text-[10px] sm:text-xs text-muted-foreground">{formatTime(reel.createdAt)}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {STATUS_ICONS[reel.status]}
                    <span className={`text-[10px] sm:text-xs font-medium capitalize ${STATUS_COLORS[reel.status] ?? "text-muted-foreground"}`}>
                      {reel.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
