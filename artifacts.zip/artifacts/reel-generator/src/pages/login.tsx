import { useState } from "react";
import { motion } from "framer-motion";
import { Link, useLocation } from "wouter";
import { Zap, Loader2, AlertCircle, Mail, Lock } from "lucide-react";
import { useLogin } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const loginMutation = useLogin();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    loginMutation.mutate(
      { data: { email, password } },
      {
        onSuccess: (result) => {
          localStorage.setItem("rf_token", result.token);
          queryClient.invalidateQueries();
          setLocation("/dashboard");
        },
        onError: () => {
          setError("Invalid email or password. Please try again.");
        },
      }
    );
  };

  return (
    <div className="min-h-screen bg-background pt-16 flex items-center justify-center px-4 py-10">
      {/* Background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[min(500px,90vw)] h-[280px] bg-primary/7 rounded-full blur-[100px]" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45 }}
        className="relative w-full max-w-md"
      >
        <div className="glass-card-elevated rounded-3xl p-7 sm:p-9">
          {/* Logo & header */}
          <div className="text-center mb-8">
            <div className="w-14 h-14 rounded-2xl bg-primary/15 border border-primary/35 flex items-center justify-center mx-auto mb-5 neon-glow-sm">
              <Zap className="w-7 h-7 text-primary" fill="currentColor" />
            </div>
            <h1 className="text-2xl sm:text-3xl font-black gradient-text">Welcome back</h1>
            <p className="text-muted-foreground text-sm mt-1.5">Log in to your ReelForge account</p>
          </div>

          {/* Error */}
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -8, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className="flex items-center gap-2.5 p-3.5 rounded-2xl bg-destructive/10 border border-destructive/25 text-destructive text-sm mb-6"
              data-testid="error-message"
            >
              <AlertCircle className="w-4 h-4 shrink-0" />
              {error}
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email */}
            <div>
              <label className="block text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2">
                Email
              </label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                  className="w-full pl-11 pr-4 py-3.5 rounded-2xl bg-white/4 border border-white/10 text-foreground placeholder-muted-foreground/60 focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/25 transition-all text-sm"
                  data-testid="input-email"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full pl-11 pr-4 py-3.5 rounded-2xl bg-white/4 border border-white/10 text-foreground placeholder-muted-foreground/60 focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/25 transition-all text-sm"
                  data-testid="input-password"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loginMutation.isPending || !email || !password}
              className="w-full mt-2 py-4 rounded-2xl bg-primary text-primary-foreground font-bold text-base neon-glow hover:bg-primary/90 transition-all flex items-center justify-center gap-2 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
              data-testid="button-submit-login"
            >
              {loginMutation.isPending ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> Logging in...</>
              ) : (
                "Log In"
              )}
            </button>
          </form>

          <div className="mt-6 pt-5 border-t border-white/6 text-center">
            <p className="text-sm text-muted-foreground">
              Don't have an account?{" "}
              <Link href="/register">
                <span className="text-primary hover:text-primary/80 transition-colors cursor-pointer font-semibold">
                  Sign up free
                </span>
              </Link>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
