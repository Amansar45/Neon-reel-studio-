import { useRef, useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "wouter";
import {
  Zap, Sparkles, Download, Music, ChevronRight, Play,
  Eye, TrendingUp, Users, Star, ArrowRight, Check,
  Wand2, Share2, BarChart3,
} from "lucide-react";
import { useGetExampleReels } from "@workspace/api-client-react";

// ── Data ──────────────────────────────────────────────────────────────────────

const STYLES = [
  {
    id: "sigma",
    label: "Sigma",
    desc: "Stoic. Ruthless. Focused. The mindset of men who build empires in silence.",
    gradient: "from-slate-400 via-zinc-300 to-slate-500",
    glow: "shadow-white/10",
    border: "border-white/15 hover:border-white/30",
    bg: "from-zinc-900 via-zinc-800/60 to-zinc-900",
    captionColor: "#FFD600",
    icon: "⚡",
    tag: "Most viral",
    tagColor: "bg-white/12 text-white/80",
  },
  {
    id: "anime_motivation",
    label: "Anime Motivation",
    desc: "High-energy, vibrant anime aesthetics fused with peak motivation content.",
    gradient: "from-pink-500 via-fuchsia-400 to-orange-400",
    glow: "shadow-pink-500/20",
    border: "border-pink-500/25 hover:border-pink-400/50",
    bg: "from-pink-950 via-fuchsia-950/80 to-purple-950",
    captionColor: "#FF5722",
    icon: "🔥",
    tag: "Trending",
    tagColor: "bg-pink-500/20 text-pink-300",
  },
  {
    id: "sad_aesthetic",
    label: "Sad Aesthetic",
    desc: "Melancholic lo-fi vibes. For the late nights when the world feels too loud.",
    gradient: "from-blue-400 via-indigo-400 to-violet-500",
    glow: "shadow-blue-500/15",
    border: "border-blue-500/25 hover:border-blue-400/50",
    bg: "from-blue-950 via-indigo-950/80 to-violet-950",
    captionColor: "#A78BFA",
    icon: "🌧",
    tag: "Emotional",
    tagColor: "bg-blue-500/20 text-blue-300",
  },
];

const STEPS = [
  {
    n: "01",
    title: "Type your vibe",
    desc: "Describe the feeling, message, or story. Any idea works.",
    icon: Sparkles,
  },
  {
    n: "02",
    title: "Pick a style",
    desc: "Choose Sigma, Anime Motivation, or Sad Aesthetic — each fully AI-crafted.",
    icon: Zap,
  },
  {
    n: "03",
    title: "Download & post",
    desc: "Your 9:16 reel with captions + music — download-ready in seconds.",
    icon: Download,
  },
];

const STATS = [
  { icon: TrendingUp, value: "2.4M+",  label: "Reels Created" },
  { icon: Users,      value: "180K+",  label: "Active Creators" },
  { icon: Star,       value: "4.9★",   label: "App Rating" },
  { icon: Zap,        value: "28s",    label: "Avg. Render Time" },
  { icon: Eye,        value: "900M+",  label: "Total Views Generated" },
];

const TESTIMONIALS = [
  {
    name: "Alex Kim",
    handle: "@alexk_sigma",
    avatar: "AK",
    followers: "284K",
    platform: "TikTok",
    category: "Sigma",
    accent: "#e2e8f0",
    glow: "rgba(226,232,240,0.18)",
    border: "border-white/12 hover:border-white/30",
    avatarGrad: "from-slate-400 to-zinc-600",
    stars: 5,
    text: "Generated 30 reels in one weekend. My TikTok went from 2K to 18K followers in 30 days. This thing is insane.",
  },
  {
    name: "Maya Rivera",
    handle: "@mayacreates",
    avatar: "MR",
    followers: "1.2M",
    platform: "Instagram",
    category: "Anime",
    accent: "#f472b6",
    glow: "rgba(244,114,182,0.22)",
    border: "border-pink-500/15 hover:border-pink-400/45",
    avatarGrad: "from-pink-500 to-fuchsia-600",
    stars: 5,
    text: "The anime motivation style blew up my Instagram Reels. 2.3M views on one video 🔥 I've tried every tool — nothing comes close.",
  },
  {
    name: "Jordan T.",
    handle: "@jt.aesthetic",
    avatar: "JT",
    followers: "89K",
    platform: "YouTube",
    category: "Sad Aesthetic",
    accent: "#818cf8",
    glow: "rgba(129,140,248,0.22)",
    border: "border-indigo-500/15 hover:border-indigo-400/45",
    avatarGrad: "from-blue-500 to-indigo-600",
    stars: 5,
    text: "I make sad aesthetic content and ReelForge nails the vibe every single time. The captions are scarily good.",
  },
  {
    name: "Sofia Lane",
    handle: "@sofiafitlane",
    avatar: "SL",
    followers: "456K",
    platform: "TikTok",
    category: "Fitness",
    accent: "#fb923c",
    glow: "rgba(251,146,60,0.22)",
    border: "border-orange-500/15 hover:border-orange-400/45",
    avatarGrad: "from-orange-500 to-red-600",
    stars: 5,
    text: "Used to spend 3 hours editing one reel. Now I batch 20 in an afternoon. My engagement rate went up 4x. Absolute game changer.",
  },
];

const PLATFORMS = [
  { label: "TikTok",             emoji: "🎵", bg: "bg-white/6",          border: "border-white/12",          text: "text-white/80"   },
  { label: "Instagram Reels",    emoji: "📸", bg: "bg-pink-500/10",      border: "border-pink-500/20",       text: "text-pink-300"   },
  { label: "YouTube Shorts",     emoji: "▶",  bg: "bg-red-500/10",       border: "border-red-500/20",        text: "text-red-300"    },
  { label: "Snapchat Spotlight", emoji: "👻", bg: "bg-yellow-500/10",    border: "border-yellow-500/20",     text: "text-yellow-300" },
];

const ACTIVITY_ITEMS = [
  { emoji: "🔥", user: "@alexksg",      action: "just hit 2.1M views on 'Sigma grindset'" },
  { emoji: "🚀", user: "@mayacreates",  action: "gained 40K followers after one ReelForge video" },
  { emoji: "💜", user: "@jt.aesthetic", action: "hit #1 trending on YouTube Shorts today" },
  { emoji: "⚡", user: "@sofiafitlane", action: "890K views in 48 hours — fitness reel" },
  { emoji: "🎬", user: "@studiomx",     action: "generated 22 reels in one afternoon" },
  { emoji: "🔥", user: "@bwcreator",    action: "Sad Aesthetic reel — 3.4M total views" },
  { emoji: "🚀", user: "@neoedits",     action: "2K → 47K followers in 30 days with ReelForge" },
];

const FEATURES_BENTO = [
  { icon: Wand2,     title: "AI Scene Builder",      desc: "Cinematic scenes auto-generated from your prompt",    color: "text-violet-400", border: "border-violet-500/20", bg: "bg-violet-500/10", glow: "rgba(167,139,250,0.18)"  },
  { icon: Music,     title: "Smart Music Matching",  desc: "Style-matched tracks that nail the exact vibe",       color: "text-pink-400",   border: "border-pink-500/20",   bg: "bg-pink-500/10",   glow: "rgba(244,114,182,0.18)"  },
  { icon: Zap,       title: "Auto Captions",         desc: "Word-by-word TikTok-style captions that drive views", color: "text-yellow-400", border: "border-yellow-500/20", bg: "bg-yellow-500/10", glow: "rgba(250,204,21,0.15)"   },
  { icon: Share2,    title: "9:16 Native Export",    desc: "Perfect vertical format for TikTok, Reels & Shorts",  color: "text-cyan-400",   border: "border-cyan-500/20",   bg: "bg-cyan-500/10",   glow: "rgba(34,211,238,0.18)"   },
  { icon: BarChart3, title: "Creator Dashboard",     desc: "Track every reel, view count, and credit in one place",color: "text-green-400", border: "border-green-500/20",  bg: "bg-green-500/10",  glow: "rgba(74,222,128,0.18)"   },
  { icon: Download,  title: "No Watermark Download", desc: "Clean MP4 ready to post — no branding on Pro plans",  color: "text-orange-400", border: "border-orange-500/20", bg: "bg-orange-500/10", glow: "rgba(251,146,60,0.18)"   },
];

const STYLE_BG: Record<string, string> = {
  sigma:            "from-slate-600/70 to-slate-900/90",
  anime_motivation: "from-pink-600/70 to-purple-900/90",
  sad_aesthetic:    "from-blue-600/70 to-indigo-900/90",
};

const TEMPLATES = [
  {
    id: "gaming",
    title: "Epic Gaming Montage",
    views: "8.2M",
    category: "Gaming",
    gradient: "from-cyan-900 via-blue-900 to-slate-900",
    glow: "rgba(6,182,212,0.55)",
    border: "hover:border-cyan-500/60",
    badge: "bg-cyan-500/15 text-cyan-300 border border-cyan-500/25",
    captionColor: "#22D3EE",
    icon: "🎮",
    caption: ["INSANE", "clutch", "play"],
    stats: ["12.4K", "3.1K", "891K"],
  },
  {
    id: "motivation",
    title: "Rise & Grind Daily",
    views: "5.7M",
    category: "Motivation",
    gradient: "from-violet-900 via-purple-900 to-indigo-950",
    glow: "rgba(139,92,246,0.55)",
    border: "hover:border-violet-500/60",
    badge: "bg-violet-500/15 text-violet-300 border border-violet-500/25",
    captionColor: "#A78BFA",
    icon: "⚡",
    caption: ["NO", "days", "off"],
    stats: ["9.2K", "2.7K", "634K"],
  },
  {
    id: "fitness",
    title: "Beast Mode Training",
    views: "4.1M",
    category: "Fitness",
    gradient: "from-orange-900 via-red-900 to-rose-950",
    glow: "rgba(249,115,22,0.55)",
    border: "hover:border-orange-500/60",
    badge: "bg-orange-500/15 text-orange-300 border border-orange-500/25",
    captionColor: "#FB923C",
    icon: "🔥",
    caption: ["PUSH", "your", "limits"],
    stats: ["7.8K", "1.9K", "421K"],
  },
  {
    id: "anime",
    title: "Anime Power Quotes",
    views: "6.9M",
    category: "Anime",
    gradient: "from-pink-900 via-fuchsia-900 to-purple-950",
    glow: "rgba(236,72,153,0.55)",
    border: "hover:border-pink-500/60",
    badge: "bg-pink-500/15 text-pink-300 border border-pink-500/25",
    captionColor: "#F472B6",
    icon: "🌸",
    caption: ["I'll", "surpass", "you"],
    stats: ["11.1K", "4.3K", "712K"],
  },
  {
    id: "business",
    title: "Startup Success Tips",
    views: "3.4M",
    category: "Business",
    gradient: "from-emerald-900 via-teal-900 to-cyan-950",
    glow: "rgba(16,185,129,0.55)",
    border: "hover:border-emerald-500/60",
    badge: "bg-emerald-500/15 text-emerald-300 border border-emerald-500/25",
    captionColor: "#34D399",
    icon: "📈",
    caption: ["build", "in", "silence"],
    stats: ["5.6K", "1.2K", "289K"],
  },
  {
    id: "study",
    title: "Late Night Study Vibe",
    views: "2.8M",
    category: "Study",
    gradient: "from-blue-900 via-indigo-900 to-violet-950",
    glow: "rgba(99,102,241,0.55)",
    border: "hover:border-indigo-500/60",
    badge: "bg-indigo-500/15 text-indigo-300 border border-indigo-500/25",
    captionColor: "#818CF8",
    icon: "📚",
    caption: ["focus", "mode", "on"],
    stats: ["4.3K", "0.9K", "198K"],
  },
];

// ── Sub-components ────────────────────────────────────────────────────────────

// ── Dashboard mockup — cyberpunk hero visual ───────────────────────────────────

const REEL_ROWS = [
  { label: "Lone wolf grindset",    style: "Sigma",  views: "4.2M", color: "from-zinc-700 to-zinc-900",   bar: "#8B5CF6" },
  { label: "Anime motivation #7",   style: "Anime",  views: "2.9M", color: "from-pink-800 to-purple-900", bar: "#FF5722" },
  { label: "3am aesthetic rain",    style: "Sad",    views: "1.8M", color: "from-blue-800 to-indigo-900", bar: "#A78BFA" },
];

const THUMB_COLORS = [
  "from-zinc-700 to-zinc-900",
  "from-pink-800 to-purple-950",
  "from-blue-800 to-indigo-950",
  "from-zinc-700 to-zinc-900",
  "from-pink-800 to-purple-950",
  "from-blue-800 to-indigo-950",
];
const THUMB_LABELS = ["Sigma", "Anime", "Sad", "Sigma", "Anime", "Sad"];

function DashboardMockupCard() {
  const [progress, setProgress] = useState(34);
  const [activeThumb, setActiveThumb] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setProgress((p) => (p >= 98 ? 12 : p + 1)), 120);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const t = setInterval(() => setActiveThumb((i) => (i + 1) % 6), 1800);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="relative flex justify-center lg:justify-end">
      {/* Multi-layer glow */}
      <div className="absolute -inset-6 bg-gradient-to-br from-violet-600/25 via-purple-600/10 to-pink-600/20 rounded-[3rem] blur-[60px] pointer-events-none" />
      <div className="absolute -inset-1 rounded-2xl bg-gradient-to-br from-violet-500/30 via-transparent to-pink-500/20 pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, y: 32, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.85, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
        whileHover={{ y: -6, transition: { duration: 0.35, ease: "easeOut" } }}
        className="relative w-full max-w-sm lg:max-w-md bg-[#0b0b12] border border-white/10 rounded-2xl overflow-hidden shadow-[0_0_60px_rgba(139,92,246,0.15)]"
      >
        {/* Subtle scan-line overlay */}
        <div className="absolute inset-0 scan-line opacity-20 pointer-events-none" />
        {/* Inner top glow */}
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-violet-400/50 to-transparent" />

        {/* ── Title bar ── */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-white/6 bg-white/[0.018]">
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-red-500/70" />
            <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/70" />
            <div className="w-2.5 h-2.5 rounded-full bg-green-500/70" />
          </div>
          <div className="flex items-center gap-1.5">
            <Zap className="w-3 h-3 text-primary" fill="currentColor" />
            <span className="text-[11px] font-semibold text-white/50 tracking-tight">ReelForge — Dashboard</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="relative flex h-1.5 w-1.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-green-400" />
            </span>
            <span className="text-[10px] font-bold text-green-400">LIVE</span>
          </div>
        </div>

        {/* ── Stats row ── */}
        <div className="grid grid-cols-3 divide-x divide-white/5 border-b border-white/5">
          {[
            { label: "Total Views", value: "2.4M", icon: TrendingUp, color: "text-violet-400" },
            { label: "Reels Made",  value: "142",   icon: Zap,        color: "text-primary"   },
            { label: "Avg Rating",  value: "4.9★",  icon: Star,       color: "text-yellow-400"},
          ].map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + i * 0.08 }}
              className="flex flex-col items-center py-3 gap-0.5"
            >
              <s.icon className={`w-3.5 h-3.5 ${s.color} mb-0.5`} />
              <span className={`text-sm font-black ${s.color} tabular-nums`}>{s.value}</span>
              <span className="text-[9px] text-white/28">{s.label}</span>
            </motion.div>
          ))}
        </div>

        {/* ── Recent reels thumbnails ── */}
        <div className="p-3.5 border-b border-white/5">
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[10px] font-bold text-white/35 uppercase tracking-widest">Recent Reels</span>
            <span className="text-[9px] text-primary cursor-pointer hover:underline">View all →</span>
          </div>
          <div className="grid grid-cols-6 gap-1.5">
            {THUMB_COLORS.map((color, i) => (
              <motion.div
                key={i}
                animate={{
                  scale: i === activeThumb ? 1.08 : 1,
                  boxShadow: i === activeThumb
                    ? "0 0 14px 2px rgba(139,92,246,0.55)"
                    : "0 0 0 0 transparent",
                }}
                transition={{ duration: 0.28 }}
                className={`aspect-[9/16] rounded-lg bg-gradient-to-b ${color} flex flex-col justify-between p-0.5 overflow-hidden relative cursor-pointer`}
              >
                <div className="absolute inset-0 scan-line opacity-40" />
                {i === activeThumb && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="absolute inset-0 flex items-center justify-center"
                  >
                    <Play className="w-2.5 h-2.5 text-white drop-shadow-lg" fill="white" />
                  </motion.div>
                )}
                <span className="text-[5.5px] text-white/40 font-bold relative z-10 leading-none mt-auto pt-4">{THUMB_LABELS[i]}</span>
              </motion.div>
            ))}
          </div>
        </div>

        {/* ── Reel performance rows ── */}
        <div className="px-3.5 py-2.5 border-b border-white/5 space-y-2">
          {REEL_ROWS.map((r, i) => (
            <div key={i} className="flex items-center gap-2.5">
              <div className={`w-7 h-7 rounded-lg bg-gradient-to-b ${r.color} shrink-0 flex items-center justify-center`}>
                <Play className="w-2.5 h-2.5 text-white/70" fill="currentColor" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-0.5">
                  <span className="text-[10px] text-white/70 font-medium truncate">{r.label}</span>
                  <span className="text-[9px] font-bold tabular-nums shrink-0 ml-2" style={{ color: r.bar }}>{r.views}</span>
                </div>
                <div className="h-[3px] rounded-full bg-white/6 overflow-hidden">
                  <motion.div
                    className="h-full rounded-full"
                    style={{ background: r.bar }}
                    initial={{ width: 0 }}
                    animate={{ width: i === 0 ? "85%" : i === 1 ? "63%" : "42%" }}
                    transition={{ delay: 0.6 + i * 0.1, duration: 0.8, ease: "easeOut" }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* ── Live generation progress ── */}
        <div className="p-3.5">
          <div className="rounded-xl border border-violet-500/20 bg-violet-500/[0.04] p-3">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5">
                <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 2, ease: "linear" }}>
                  <Sparkles className="w-3 h-3 text-primary" />
                </motion.div>
                <span className="text-[10px] text-white/55 font-medium">Generating reel...</span>
              </div>
              <span className="text-[11px] font-black text-primary tabular-nums">{progress}%</span>
            </div>
            <div className="h-1.5 rounded-full bg-white/6 overflow-hidden mb-1.5">
              <motion.div
                className="h-full rounded-full bg-gradient-to-r from-violet-500 via-fuchsia-500 to-pink-500"
                style={{ boxShadow: "0 0 10px rgba(139,92,246,0.7)" }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.12 }}
              />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[9px] text-white/28 truncate">"lone wolf grindset cinematic"</span>
              <span className="text-[9px] text-white/20 shrink-0 ml-2">~{Math.max(1, Math.round((100 - progress) * 0.3))}s left</span>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

// Mini 9:16 phone card used inside style cards
function StylePhone({ style }: { style: typeof STYLES[0] }) {
  const [wordIdx, setWordIdx] = useState(0);
  const CAPTION_WORDS = ["go", "viral", "now"];
  useEffect(() => {
    const t = setInterval(() => setWordIdx((i) => (i + 1) % CAPTION_WORDS.length), 900);
    return () => clearInterval(t);
  }, []);

  return (
    <div
      className={`relative w-full rounded-2xl overflow-hidden bg-gradient-to-b ${style.bg} border ${style.border} transition-all duration-300`}
      style={{ aspectRatio: "9/16" }}
    >
      {/* Scan line */}
      <div className="absolute inset-0 scan-line opacity-50" />
      {/* Glow */}
      <div className={`absolute inset-0 bg-gradient-to-b ${style.bg} opacity-80`} />

      {/* Fake TikTok UI */}
      <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
        <div className="w-12 h-1 rounded-full bg-white/20" />
        <div className="w-4 h-4 rounded-full bg-white/15 border border-white/20" />
      </div>

      {/* Animated caption */}
      <div className="absolute inset-x-3 bottom-[20%] flex flex-wrap gap-[2px] justify-center">
        {CAPTION_WORDS.map((w, i) => (
          <motion.span
            key={`${wordIdx}-${i}`}
            initial={{ opacity: 0, scale: 0.4 }}
            animate={{ opacity: wordIdx >= i ? 1 : 0.25, scale: wordIdx === i ? 1 : 0.85 }}
            transition={{ delay: i * 0.1, duration: 0.2 }}
            className="text-[10px] font-black uppercase leading-none"
            style={{
              color: wordIdx === i ? style.captionColor : "#fff",
              textShadow: "0 1px 4px #000",
            }}
          >
            {w}
          </motion.span>
        ))}
      </div>

      {/* Bottom scrim */}
      <div className="absolute inset-x-0 bottom-0 h-[30%] bg-gradient-to-t from-black/80 to-transparent" />

      {/* TikTok right sidebar icons */}
      <div className="absolute right-2 bottom-[35%] flex flex-col gap-3 items-center">
        {["♥", "💬", "↗"].map((ic, i) => (
          <div key={i} className="flex flex-col items-center">
            <div className="w-6 h-6 rounded-full bg-white/12 border border-white/20 flex items-center justify-center text-[9px]">{ic}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── AI Generator demo data ────────────────────────────────────────────────────

const DEMO_CATEGORIES = [
  { id: "motivation", label: "⚡ Motivation",  gradient: "from-violet-900 via-purple-900 to-indigo-950", glow: "rgba(139,92,246,0.5)",  captionColor: "#A78BFA", icon: "⚡" },
  { id: "gaming",     label: "🎮 Gaming",     gradient: "from-cyan-900 via-blue-900 to-slate-900",       glow: "rgba(6,182,212,0.5)",   captionColor: "#22D3EE", icon: "🎮" },
  { id: "fitness",    label: "🔥 Fitness",    gradient: "from-orange-900 via-red-900 to-rose-950",        glow: "rgba(249,115,22,0.5)",  captionColor: "#FB923C", icon: "🔥" },
  { id: "anime",      label: "🌸 Anime",      gradient: "from-pink-900 via-fuchsia-900 to-purple-950",    glow: "rgba(236,72,153,0.5)",  captionColor: "#F472B6", icon: "🌸" },
  { id: "business",   label: "📈 Business",   gradient: "from-emerald-900 via-teal-900 to-cyan-950",      glow: "rgba(16,185,129,0.5)",  captionColor: "#34D399", icon: "📈" },
  { id: "study",      label: "📚 Study",      gradient: "from-blue-900 via-indigo-900 to-violet-950",     glow: "rgba(99,102,241,0.5)",  captionColor: "#818CF8", icon: "📚" },
];

const LOADING_STEPS = [
  "Analyzing your idea...",
  "Generating cinematic scenes...",
  "Adding captions & music...",
  "Rendering your reel...",
];

// ── AI Generator demo component ────────────────────────────────────────────────

type GenPhase = "idle" | "loading" | "done";

function ReelGeneratorDemo() {
  const [idea, setIdea] = useState("");
  const [categoryId, setCategoryId] = useState("motivation");
  const [phase, setPhase] = useState<GenPhase>("idle");
  const [loadingStep, setLoadingStep] = useState(0);
  const [progress, setProgress] = useState(0);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const cat = DEMO_CATEGORIES.find((c) => c.id === categoryId) ?? DEMO_CATEGORIES[0];

  // Extract up to 3 highlight words from the idea for the caption preview
  const captionWords = idea.trim()
    ? idea.trim().split(/\s+/).slice(0, 3).map((w) => w.replace(/[^a-zA-Z0-9]/g, ""))
    : ["go", "viral", "now"];

  function handleGenerate() {
    if (phase === "loading") return;
    setPhase("loading");
    setLoadingStep(0);
    setProgress(0);

    const STEP_MS = [900, 850, 800, 750];
    let elapsed = 0;
    const total = STEP_MS.reduce((a, b) => a + b, 0) + 200;

    STEP_MS.forEach((ms, i) => {
      timerRef.current = setTimeout(() => {
        setLoadingStep(i + 1);
        elapsed += ms;
        setProgress(Math.round((elapsed / total) * 100));
      }, STEP_MS.slice(0, i).reduce((a, b) => a + b, 0) + ms);
    });

    timerRef.current = setTimeout(() => {
      setProgress(100);
      setTimeout(() => setPhase("done"), 200);
    }, total);
  }

  function handleReset() {
    setPhase("idle");
    setLoadingStep(0);
    setProgress(0);
  }

  useEffect(() => () => { if (timerRef.current) clearTimeout(timerRef.current); }, []);

  return (
    <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-start">

      {/* ── Left: form ── */}
      <div className="flex flex-col gap-5">

        {/* Idea input */}
        <div className="flex flex-col gap-2">
          <label className="text-xs font-bold text-white/40 uppercase tracking-widest">Your Reel Idea</label>
          <div className="relative">
            <textarea
              rows={4}
              value={idea}
              onChange={(e) => setIdea(e.target.value)}
              placeholder="Type your reel idea…"
              disabled={phase !== "idle"}
              className="w-full bg-white/[0.04] border border-white/10 rounded-2xl px-4 py-3.5 text-sm text-foreground placeholder:text-muted-foreground/40 resize-none focus:outline-none focus:border-primary/50 focus:bg-white/[0.06] transition-all disabled:opacity-50"
            />
            {/* Corner sparkle */}
            <Sparkles className="absolute bottom-3 right-3 w-4 h-4 text-primary/40" />
          </div>
        </div>

        {/* Category select */}
        <div className="flex flex-col gap-2">
          <label className="text-xs font-bold text-white/40 uppercase tracking-widest">Category</label>
          <div className="relative">
            <select
              value={categoryId}
              onChange={(e) => { setCategoryId(e.target.value); if (phase === "done") handleReset(); }}
              disabled={phase !== "idle"}
              className="w-full appearance-none bg-white/[0.04] border border-white/10 rounded-2xl px-4 py-3.5 pr-10 text-sm text-foreground focus:outline-none focus:border-primary/50 focus:bg-white/[0.06] transition-all cursor-pointer disabled:opacity-50"
            >
              {DEMO_CATEGORIES.map((c) => (
                <option key={c.id} value={c.id} className="bg-zinc-900">{c.label}</option>
              ))}
            </select>
            <ChevronRight className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30 rotate-90 pointer-events-none" />
          </div>
        </div>

        {/* Style pills */}
        <div className="flex flex-col gap-2">
          <label className="text-xs font-bold text-white/40 uppercase tracking-widest">Reel Style</label>
          <div className="flex flex-wrap gap-2">
            {["Cinematic", "Lo-fi", "Fast-cut", "Aesthetic"].map((s) => (
              <button
                key={s}
                className="px-3.5 py-1.5 rounded-xl text-xs font-semibold border border-white/10 bg-white/[0.03] text-white/50 hover:border-primary/40 hover:text-primary hover:bg-primary/8 transition-all"
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Generate button */}
        {phase === "idle" && (
          <motion.button
            onClick={handleGenerate}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.97 }}
            className="relative w-full flex items-center justify-center gap-2.5 py-4 rounded-2xl bg-primary text-primary-foreground font-bold text-base neon-glow overflow-hidden group"
          >
            <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full bg-gradient-to-r from-transparent via-white/15 to-transparent transition-transform duration-500" />
            <Zap className="w-5 h-5 relative z-10" fill="currentColor" />
            <span className="relative z-10">Generate My Reel</span>
          </motion.button>
        )}

        {phase === "done" && (
          <motion.button
            onClick={handleReset}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.97 }}
            className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl border border-white/12 text-muted-foreground font-medium hover:bg-white/5 hover:text-foreground transition-all"
          >
            ↺ Generate another
          </motion.button>
        )}

        {/* Loading steps */}
        <AnimatePresence>
          {phase === "loading" && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="flex flex-col gap-3 overflow-hidden"
            >
              {/* Progress bar */}
              <div className="h-1.5 rounded-full bg-white/6 overflow-hidden">
                <motion.div
                  className="h-full rounded-full bg-gradient-to-r from-violet-500 via-fuchsia-500 to-pink-500"
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.3 }}
                  style={{ boxShadow: "0 0 10px rgba(139,92,246,0.7)" }}
                />
              </div>
              {/* Steps list */}
              <div className="flex flex-col gap-2.5">
                {LOADING_STEPS.map((label, i) => {
                  const done = i < loadingStep;
                  const active = i === loadingStep - 1 && phase === "loading";
                  return (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -8 }}
                      animate={{ opacity: done || active ? 1 : 0.25, x: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="flex items-center gap-3"
                    >
                      <div className={`w-5 h-5 rounded-full border flex items-center justify-center text-[10px] shrink-0 transition-all ${done ? "bg-primary border-primary" : active ? "border-primary/60 animate-pulse" : "border-white/15"}`}>
                        {done ? "✓" : <motion.div animate={active ? { rotate: 360 } : {}} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}><Sparkles className="w-2.5 h-2.5 text-primary/60" /></motion.div>}
                      </div>
                      <span className={`text-xs font-medium transition-colors ${done ? "text-white/60 line-through" : active ? "text-white" : "text-white/25"}`}>{label}</span>
                      {active && <span className="ml-auto text-[10px] text-primary tabular-nums">{progress}%</span>}
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Success credits note */}
        <AnimatePresence>
          {phase === "done" && (
            <motion.div
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="flex items-center gap-2 text-xs text-muted-foreground"
            >
              <span className="w-2 h-2 rounded-full bg-green-400 shrink-0 animate-pulse" />
              1 credit used · 2 free credits remaining
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── Right: preview phone ── */}
      <div className="flex flex-col items-center gap-5">
        <div className="relative w-full max-w-[220px] mx-auto">

          {/* Glow behind phone */}
          <motion.div
            animate={{ opacity: phase === "done" ? 0.5 : 0.15, scale: phase === "done" ? 1.08 : 1 }}
            transition={{ duration: 0.6 }}
            className="absolute -inset-6 rounded-[50px] blur-[50px] pointer-events-none"
            style={{ background: `radial-gradient(ellipse at center, ${cat.glow}, transparent 70%)` }}
          />

          {/* Phone chrome */}
          <div className="relative">
            {/* Notch */}
            <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-16 h-1 rounded-full bg-white/10 z-20" />
            {/* Outer ring */}
            <div className="absolute -inset-2 rounded-[34px] border border-white/6 bg-gradient-to-b from-white/3 to-transparent pointer-events-none z-10" />

            {/* Screen */}
            <AnimatePresence mode="wait">
              {phase === "idle" && (
                <motion.div
                  key="idle"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="w-full rounded-[28px] overflow-hidden border border-white/10 bg-zinc-900 flex flex-col items-center justify-center gap-3 text-center px-4"
                  style={{ aspectRatio: "9/16" }}
                >
                  <div className="w-12 h-12 rounded-2xl border border-white/10 bg-white/5 flex items-center justify-center text-2xl">🎬</div>
                  <p className="text-xs text-muted-foreground leading-relaxed">Your reel preview will appear here after generation</p>
                  <div className="flex gap-1">
                    {[...Array(3)].map((_, i) => (
                      <motion.div key={i} className="w-1.5 h-1.5 rounded-full bg-white/20"
                        animate={{ opacity: [0.2, 1, 0.2] }}
                        transition={{ repeat: Infinity, duration: 1.4, delay: i * 0.2 }}
                      />
                    ))}
                  </div>
                </motion.div>
              )}

              {phase === "loading" && (
                <motion.div
                  key="loading"
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.96 }}
                  className={`relative w-full rounded-[28px] overflow-hidden border border-white/10 bg-gradient-to-b ${cat.gradient}`}
                  style={{ aspectRatio: "9/16" }}
                >
                  <div className="absolute inset-0 scan-line opacity-40" />
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 px-6">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                      className="text-3xl"
                    >
                      {cat.icon}
                    </motion.div>
                    <div className="w-full">
                      <div className="h-1 rounded-full bg-white/10 overflow-hidden">
                        <motion.div
                          className="h-full rounded-full"
                          style={{ background: cat.captionColor, boxShadow: `0 0 8px ${cat.glow}` }}
                          animate={{ width: `${progress}%` }}
                          transition={{ duration: 0.3 }}
                        />
                      </div>
                    </div>
                    <p className="text-[10px] text-white/50 text-center">{LOADING_STEPS[Math.max(0, loadingStep - 1)]}</p>
                  </div>
                </motion.div>
              )}

              {phase === "done" && (
                <motion.div
                  key="done"
                  initial={{ opacity: 0, scale: 0.94, y: 12 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
                  className={`relative w-full rounded-[28px] overflow-hidden border bg-gradient-to-b ${cat.gradient}`}
                  style={{ aspectRatio: "9/16", borderColor: `${cat.captionColor}40` }}
                >
                  <div className="absolute inset-0 scan-line opacity-40" />
                  {/* Top bar */}
                  <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
                    <div className="w-10 h-0.5 rounded-full bg-white/20" />
                    <div className="w-4 h-4 rounded-full bg-white/12 border border-white/20" />
                  </div>
                  {/* Center icon */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <motion.div
                      animate={{ scale: [1, 1.1, 1] }}
                      transition={{ repeat: Infinity, duration: 2.5 }}
                      className="text-4xl"
                    >{cat.icon}</motion.div>
                  </div>
                  {/* Captions */}
                  <div className="absolute inset-x-3 bottom-[22%] flex flex-col items-center gap-0.5">
                    {captionWords.map((word, wi) => (
                      <motion.span
                        key={wi}
                        initial={{ opacity: 0, y: 6, scale: 0.8 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        transition={{ delay: 0.1 + wi * 0.12, ease: [0.22, 1, 0.36, 1] }}
                        className="text-[13px] font-black uppercase leading-none tracking-wide"
                        style={{ color: wi === 1 ? cat.captionColor : "white", textShadow: "0 2px 8px #000" }}
                      >
                        {word || "viral"}
                      </motion.span>
                    ))}
                  </div>
                  {/* Bottom scrim */}
                  <div className="absolute inset-x-0 bottom-0 h-[28%] bg-gradient-to-t from-black/80 to-transparent" />
                  {/* Bottom stats */}
                  <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      <Play className="w-2.5 h-2.5 text-white/60 ml-0.5" fill="currentColor" />
                      <span className="text-[8px] text-white/50">4.2M</span>
                    </div>
                    <div className="flex gap-1.5">
                      <span className="text-[8px] text-white/40">♥ 812K</span>
                      <span className="text-[8px] text-white/40">↗ 203K</span>
                    </div>
                  </div>
                  {/* Right sidebar */}
                  <div className="absolute right-2.5 bottom-[35%] flex flex-col gap-3 items-center">
                    {[["♥", "812K"], ["💬", "4.2K"], ["↗", "203K"]].map(([ic, val], i) => (
                      <div key={i} className="flex flex-col items-center">
                        <div className="w-6 h-6 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-[9px]">{ic}</div>
                        <span className="text-[6px] text-white/35 mt-0.5">{val}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Action buttons — shown after generation */}
        <AnimatePresence>
          {phase === "done" && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ delay: 0.3 }}
              className="flex gap-3 w-full max-w-[220px]"
            >
              <Link href="/generate" className="flex-1">
                <span className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-primary text-primary-foreground text-xs font-bold neon-glow hover:bg-primary/90 transition-all cursor-pointer">
                  <Download className="w-3.5 h-3.5" />
                  Export
                </span>
              </Link>
              <Link href="/generate" className="flex-1">
                <span className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-xl border border-white/12 text-xs font-medium text-muted-foreground hover:bg-white/5 hover:text-foreground transition-all cursor-pointer">
                  <ArrowRight className="w-3.5 h-3.5" />
                  Full Editor
                </span>
              </Link>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

// ── Waitlist form component ────────────────────────────────────────────────────

type WaitlistStatus = "idle" | "submitting" | "success" | "duplicate";

function WaitlistForm() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<WaitlistStatus>("idle");
  const [count, setCount] = useState(0);

  useEffect(() => {
    try {
      const stored: string[] = JSON.parse(localStorage.getItem("rf_waitlist") ?? "[]");
      setCount(stored.length);
    } catch { /* ignore */ }
  }, []);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const trimmed = email.trim().toLowerCase();
    if (!trimmed || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) return;

    setStatus("submitting");

    setTimeout(() => {
      try {
        const stored: string[] = JSON.parse(localStorage.getItem("rf_waitlist") ?? "[]");
        if (stored.includes(trimmed)) {
          setStatus("duplicate");
          return;
        }
        stored.push(trimmed);
        localStorage.setItem("rf_waitlist", JSON.stringify(stored));
        setCount(stored.length);
        setStatus("success");
      } catch {
        setStatus("success");
      }
    }, 1200);
  }

  function handleReset() {
    setEmail("");
    setStatus("idle");
  }

  return (
    <div className="w-full max-w-xl mx-auto">
      <AnimatePresence mode="wait">

        {/* ── Idle / submitting ── */}
        {(status === "idle" || status === "submitting") && (
          <motion.form
            key="form"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10, scale: 0.97 }}
            transition={{ duration: 0.4 }}
            onSubmit={handleSubmit}
            className="flex flex-col sm:flex-row gap-3"
          >
            {/* Email input */}
            <div className="relative flex-1">
              {/* Input glow on focus */}
              <div className="absolute -inset-px rounded-2xl bg-gradient-to-r from-violet-500/0 via-violet-500/0 to-pink-500/0 peer-focus:from-violet-500/30 peer-focus:to-pink-500/20 transition-all duration-300 pointer-events-none" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email address…"
                required
                disabled={status === "submitting"}
                className="peer w-full bg-white/[0.06] border border-white/12 rounded-2xl px-5 py-4 text-sm text-foreground placeholder:text-muted-foreground/45 focus:outline-none focus:border-primary/55 focus:bg-white/[0.09] transition-all disabled:opacity-60"
              />
            </div>

            {/* Submit button */}
            <motion.button
              type="submit"
              disabled={status === "submitting" || !email.trim()}
              whileHover={status === "idle" ? { scale: 1.03 } : {}}
              whileTap={status === "idle" ? { scale: 0.97 } : {}}
              className="relative flex items-center justify-center gap-2.5 px-7 py-4 rounded-2xl bg-primary text-primary-foreground font-bold text-sm neon-glow overflow-hidden disabled:opacity-60 shrink-0 group"
            >
              <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full bg-gradient-to-r from-transparent via-white/18 to-transparent transition-transform duration-500" />
              {status === "submitting" ? (
                <>
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 0.9, ease: "linear" }}
                    className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full relative z-10"
                  />
                  <span className="relative z-10">Joining…</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 relative z-10" fill="currentColor" />
                  <span className="relative z-10">Join Waitlist</span>
                </>
              )}
            </motion.button>
          </motion.form>
        )}

        {/* ── Success ── */}
        {status === "success" && (
          <motion.div
            key="success"
            initial={{ opacity: 0, scale: 0.9, y: 16 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
            className="relative flex flex-col items-center gap-4 py-8 px-6 rounded-3xl border border-green-500/25 bg-green-500/[0.05] text-center"
          >
            {/* Animated ring + checkmark */}
            <div className="relative">
              <motion.div
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.1, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                className="w-16 h-16 rounded-full bg-green-500/15 border border-green-500/35 flex items-center justify-center"
                style={{ boxShadow: "0 0 28px rgba(34,197,94,0.3)" }}
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.25, duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                >
                  <Check className="w-8 h-8 text-green-400" strokeWidth={2.5} />
                </motion.div>
              </motion.div>
              {/* Ping rings */}
              {[0, 1].map((r) => (
                <motion.div
                  key={r}
                  className="absolute inset-0 rounded-full border border-green-500/30"
                  animate={{ scale: [1, 1.8, 2.2], opacity: [0.4, 0.1, 0] }}
                  transition={{ repeat: Infinity, duration: 1.8, delay: r * 0.6, ease: "easeOut" }}
                />
              ))}
            </div>

            <div>
              <motion.h3
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="text-xl font-black text-foreground mb-1"
              >
                You're on the list! 🎉
              </motion.h3>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.42 }}
                className="text-sm text-muted-foreground"
              >
                We'll notify <span className="text-primary font-medium">{email.trim()}</span> when you get early access.
              </motion.p>
            </div>

            {/* Floating particles */}
            {["✦", "★", "✦", "◆", "✦"].map((sym, pi) => (
              <motion.span
                key={pi}
                className="absolute text-green-400/60 text-xs font-black pointer-events-none select-none"
                style={{ left: `${15 + pi * 18}%`, top: "20%" }}
                initial={{ opacity: 0, y: 0 }}
                animate={{ opacity: [0, 1, 0], y: -32 }}
                transition={{ delay: 0.3 + pi * 0.1, duration: 1.2, ease: "easeOut" }}
              >
                {sym}
              </motion.span>
            ))}

            <motion.button
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
              onClick={handleReset}
              className="text-xs text-muted-foreground/50 hover:text-muted-foreground transition-colors mt-1"
            >
              Submit another email →
            </motion.button>
          </motion.div>
        )}

        {/* ── Duplicate ── */}
        {status === "duplicate" && (
          <motion.div
            key="duplicate"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center gap-3 py-6 px-6 rounded-3xl border border-violet-500/20 bg-violet-500/[0.05] text-center"
          >
            <span className="text-2xl">👋</span>
            <p className="text-sm text-muted-foreground">
              <span className="text-primary font-medium">{email.trim()}</span> is already on the waitlist!
            </p>
            <button onClick={handleReset} className="text-xs text-primary hover:underline">
              Use a different email →
            </button>
          </motion.div>
        )}

      </AnimatePresence>

      {/* Social proof counter */}
      {(status === "idle" || status === "submitting") && (
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-center text-xs text-muted-foreground/45 mt-4 flex items-center justify-center gap-1.5"
        >
          <span className="relative flex h-1.5 w-1.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-green-400" />
          </span>
          {count > 0 ? `${count.toLocaleString()} people` : "Creators"} already on the waitlist · Free forever for early members
        </motion.p>
      )}
    </div>
  );
}

// ── Sticky mobile CTA ─────────────────────────────────────────────────────────

function StickyCTA() {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 600);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          key="sticky-cta"
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ type: "spring", stiffness: 340, damping: 32 }}
          className="fixed bottom-0 inset-x-0 z-40 sm:hidden pb-safe"
        >
          <div className="bg-background/96 backdrop-blur-2xl border-t border-white/8 px-4 py-3 flex gap-2.5 shadow-[0_-8px_32px_rgba(0,0,0,0.5)]">
            <Link href="/generate" className="flex-1">
              <span className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-primary text-white font-bold text-sm neon-glow cursor-pointer">
                <Zap className="w-4 h-4" fill="currentColor" />
                Create Free Reel
              </span>
            </Link>
            <Link href="/pricing">
              <span className="flex items-center justify-center px-5 py-3.5 rounded-2xl border border-white/12 text-muted-foreground text-sm font-semibold cursor-pointer hover:bg-white/5 transition-colors">
                Plans
              </span>
            </Link>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ── Floating particles ────────────────────────────────────────────────────────

const PARTICLES = [
  { id:  0, x:  6, y: 80, size: 2.5, color: "rgba(139,92,246,0.7)",  dur: 7,   delay: 0.0 },
  { id:  1, x: 18, y: 55, size: 1.5, color: "rgba(6,182,212,0.6)",   dur: 5.5, delay: 0.8 },
  { id:  2, x: 28, y: 70, size: 3.0, color: "rgba(236,72,153,0.55)", dur: 8,   delay: 1.6 },
  { id:  3, x: 39, y: 85, size: 1.5, color: "rgba(139,92,246,0.5)",  dur: 6,   delay: 0.4 },
  { id:  4, x: 51, y: 60, size: 2.0, color: "rgba(6,182,212,0.65)",  dur: 9,   delay: 2.2 },
  { id:  5, x: 62, y: 75, size: 2.5, color: "rgba(236,72,153,0.5)",  dur: 6.5, delay: 1.0 },
  { id:  6, x: 74, y: 50, size: 1.5, color: "rgba(139,92,246,0.6)",  dur: 7.5, delay: 3.0 },
  { id:  7, x: 83, y: 82, size: 3.0, color: "rgba(6,182,212,0.5)",   dur: 5,   delay: 0.6 },
  { id:  8, x: 92, y: 65, size: 2.0, color: "rgba(236,72,153,0.6)",  dur: 8.5, delay: 1.8 },
  { id:  9, x: 12, y: 40, size: 1.5, color: "rgba(139,92,246,0.45)", dur: 6,   delay: 2.4 },
  { id: 10, x: 45, y: 30, size: 2.5, color: "rgba(6,182,212,0.55)",  dur: 7,   delay: 0.2 },
  { id: 11, x: 67, y: 90, size: 2.0, color: "rgba(236,72,153,0.5)",  dur: 5.5, delay: 3.5 },
  { id: 12, x: 33, y: 20, size: 1.5, color: "rgba(139,92,246,0.5)",  dur: 9,   delay: 1.2 },
  { id: 13, x: 78, y: 35, size: 3.0, color: "rgba(6,182,212,0.45)",  dur: 6.5, delay: 2.8 },
  { id: 14, x: 55, y: 15, size: 2.0, color: "rgba(236,72,153,0.6)",  dur: 7,   delay: 0.9 },
  { id: 15, x:  3, y: 45, size: 1.5, color: "rgba(139,92,246,0.6)",  dur: 8,   delay: 4.0 },
  { id: 16, x: 87, y: 20, size: 2.5, color: "rgba(6,182,212,0.5)",   dur: 5.5, delay: 1.5 },
  { id: 17, x: 22, y: 10, size: 2.0, color: "rgba(236,72,153,0.45)", dur: 7.5, delay: 3.2 },
  { id: 18, x: 95, y: 50, size: 1.5, color: "rgba(139,92,246,0.55)", dur: 6,   delay: 0.7 },
  { id: 19, x: 48, y: 95, size: 3.0, color: "rgba(6,182,212,0.6)",   dur: 9,   delay: 2.0 },
];

function FloatingParticles() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {PARTICLES.map((p) => (
        <motion.div
          key={p.id}
          className="absolute rounded-full"
          style={{ width: p.size, height: p.size, left: `${p.x}%`, top: `${p.y}%`, background: p.color, filter: "blur(0.5px)" }}
          animate={{
            y: [0, -55 - (p.id % 4) * 14, 0],
            x: [0, ((p.id % 5) - 2) * 18, 0],
            opacity: [0, 0.9, 0],
            scale: [0.3, 1.2, 0.3],
          }}
          transition={{ repeat: Infinity, duration: p.dur, delay: p.delay, ease: "easeInOut" }}
        />
      ))}
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────

const itemVariants = {
  hidden:  { opacity: 0, y: 28 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.55, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] } },
};
const containerVariants = {
  hidden:  { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
};

export default function HomePage() {
  const { data: examples, isLoading: examplesLoading } = useGetExampleReels();
  const scrollRef = useRef<HTMLDivElement>(null);

  return (
    <div className="min-h-screen bg-background page-enter">

      {/* ── Hero ─────────────────────────────────────────────────── */}
      <section className="relative pt-24 pb-24 px-4 sm:px-6 lg:px-8 overflow-hidden">

        {/* ── Cyberpunk animated background ── */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {/* Primary violet orb — pulses */}
          <motion.div
            animate={{ scale: [1, 1.1, 1], opacity: [0.18, 0.28, 0.18] }}
            transition={{ repeat: Infinity, duration: 5, ease: "easeInOut" }}
            className="absolute -top-32 left-1/2 -translate-x-1/2 w-[900px] h-[650px] rounded-full bg-violet-600 blur-[130px]"
          />
          {/* Left cyan orb */}
          <motion.div
            animate={{ scale: [1, 1.15, 1], opacity: [0.08, 0.15, 0.08] }}
            transition={{ repeat: Infinity, duration: 6, ease: "easeInOut", delay: 1.2 }}
            className="absolute top-1/3 -left-40 w-[480px] h-[480px] rounded-full bg-cyan-500 blur-[110px]"
          />
          {/* Right pink orb */}
          <motion.div
            animate={{ scale: [1, 1.12, 1], opacity: [0.07, 0.14, 0.07] }}
            transition={{ repeat: Infinity, duration: 7, ease: "easeInOut", delay: 2.5 }}
            className="absolute top-1/4 -right-32 w-[420px] h-[420px] rounded-full bg-fuchsia-600 blur-[110px]"
          />
          {/* Bottom fill */}
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[700px] h-[180px] rounded-full bg-indigo-700/15 blur-[80px]" />
          {/* Neon-tinted grid */}
          <div
            className="absolute inset-0 opacity-[0.045]"
            style={{
              backgroundImage: "linear-gradient(rgba(139,92,246,0.9) 1px, transparent 1px), linear-gradient(90deg, rgba(139,92,246,0.9) 1px, transparent 1px)",
              backgroundSize: "52px 52px",
            }}
          />
          {/* Scan line */}
          <div className="absolute inset-0 scan-line opacity-20" />
          {/* Floating particles */}
          <FloatingParticles />
          {/* Bottom vignette */}
          <div className="absolute bottom-0 inset-x-0 h-40 bg-gradient-to-t from-background to-transparent" />
        </div>

        <div className="relative max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">

            {/* ── Left: copy ── */}
            <div className="text-center lg:text-left">

              {/* Live badge */}
              <motion.div
                initial={{ opacity: 0, y: -14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary/10 border border-primary/30 text-primary text-xs sm:text-sm font-semibold mb-7"
              >
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
                </span>
                🔥 2.4M+ reels made · 900M+ views generated
              </motion.div>

              {/* Headline */}
              <motion.h1
                initial={{ opacity: 0, y: 32 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.75, delay: 0.07, ease: [0.22, 1, 0.36, 1] }}
                className="text-[3.2rem] sm:text-[4.5rem] lg:text-[5.25rem] xl:text-[6rem] font-black tracking-tight leading-[0.97] mb-6"
              >
                Turn any idea<br />
                <span className="shimmer-text">into a viral</span><br />
                reel.
              </motion.h1>

              {/* Subtitle */}
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.17 }}
                className="text-base sm:text-lg lg:text-xl text-muted-foreground max-w-lg mx-auto lg:mx-0 mb-9 leading-relaxed"
              >
                Drop a prompt — ReelForge writes the script, builds cinematic scenes, syncs music and captions, then renders a TikTok-ready 9:16 reel in seconds.
              </motion.p>

              {/* CTAs */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.24 }}
                className="flex flex-col sm:flex-row items-center lg:items-start gap-3 mb-9"
              >
                {/* Primary */}
                <Link href="/generate">
                  <span
                    className="relative flex items-center gap-2.5 px-8 py-4 bg-primary text-primary-foreground rounded-2xl font-bold text-base sm:text-lg neon-glow hover:bg-primary/90 transition-all cursor-pointer w-full sm:w-auto justify-center group overflow-hidden"
                    data-testid="button-hero-generate"
                  >
                    <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full bg-gradient-to-r from-transparent via-white/18 to-transparent transition-transform duration-500" />
                    <Zap className="w-5 h-5 relative z-10" fill="currentColor" />
                    <span className="relative z-10">Start Creating</span>
                  </span>
                </Link>

                {/* Watch Demo — scrolls to example reels */}
                <a href="#examples">
                  <span className="flex items-center gap-2.5 px-8 py-4 border border-white/12 text-muted-foreground rounded-2xl font-medium hover:bg-white/5 hover:text-foreground hover:border-white/25 transition-all cursor-pointer w-full sm:w-auto justify-center group">
                    <span className="w-8 h-8 rounded-full bg-white/6 border border-white/12 flex items-center justify-center shrink-0 group-hover:bg-primary/15 group-hover:border-primary/30 transition-all">
                      <Play className="w-3.5 h-3.5 ml-0.5 text-white/60 group-hover:text-primary transition-colors" fill="currentColor" />
                    </span>
                    Watch Demo
                  </span>
                </a>
              </motion.div>

              {/* Social proof */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.44 }}
                className="flex flex-col sm:flex-row items-center lg:items-start gap-4"
              >
                <div className="flex -space-x-2">
                  {["AK", "MR", "JT", "SL", "BW"].map((initials, i) => (
                    <div key={i} className="w-8 h-8 rounded-full border-2 border-background bg-gradient-to-br from-primary/60 to-accent/60 flex items-center justify-center text-[9px] font-bold text-white">
                      {initials}
                    </div>
                  ))}
                </div>
                <div className="text-left">
                  <div className="flex items-center gap-0.5">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
                    ))}
                    <span className="ml-1.5 text-sm font-bold">4.9</span>
                  </div>
                  <p className="text-xs text-muted-foreground">Loved by 180K+ creators</p>
                </div>
              </motion.div>
            </div>

            {/* ── Right: dashboard mockup ── */}
            <motion.div
              initial={{ opacity: 0, x: 48 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.9, delay: 0.18, ease: [0.22, 1, 0.36, 1] }}
            >
              <DashboardMockupCard />
            </motion.div>

          </div>
        </div>
      </section>

      {/* ── Trending Reel Templates ──────────────────────────────── */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Background glow */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-violet-600/8 rounded-full blur-[100px]" />
        </div>

        <div className="relative max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 22 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/25 text-orange-400 text-xs font-bold mb-5 tracking-wide uppercase">
              <TrendingUp className="w-3.5 h-3.5" />
              Trending This Week
            </div>
            <h2 className="text-3xl sm:text-5xl font-black tracking-tight mb-4">
              Trending Reel{" "}
              <span className="gradient-text">Templates</span>
            </h2>
            <p className="text-muted-foreground text-base sm:text-lg max-w-xl mx-auto">
              Pick a proven format — AI fills in the rest. One click to generate your version.
            </p>
          </motion.div>

          {/* Cards grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {TEMPLATES.map((t, i) => (
              <motion.div
                key={t.id}
                initial={{ opacity: 0, y: 32, scale: 0.94 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.07, ease: [0.22, 1, 0.36, 1] }}
                whileHover={{ y: -8, transition: { duration: 0.25, ease: "easeOut" } }}
                className={`group relative flex flex-col rounded-2xl border border-white/8 bg-white/[0.03] backdrop-blur-sm overflow-hidden cursor-pointer transition-all duration-300 ${t.border}`}
                style={{ "--glow": t.glow } as React.CSSProperties}
              >
                {/* Animated neon border glow on hover */}
                <div
                  className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
                  style={{ boxShadow: `0 0 22px 2px ${t.glow}, inset 0 0 22px 0px ${t.glow}22` }}
                />

                {/* Thumbnail — 9:16 mini reel preview */}
                <div className={`relative bg-gradient-to-b ${t.gradient} overflow-hidden`} style={{ aspectRatio: "9/16" }}>
                  {/* Scan line */}
                  <div className="absolute inset-0 scan-line opacity-40" />
                  {/* Fake top bar */}
                  <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between">
                    <div className="w-8 h-0.5 rounded-full bg-white/20" />
                    <div className="w-3 h-3 rounded-full bg-white/12 border border-white/20" />
                  </div>
                  {/* Category icon — center */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <motion.div
                      animate={{ scale: [1, 1.12, 1] }}
                      transition={{ repeat: Infinity, duration: 2.5 + i * 0.3, ease: "easeInOut" }}
                      className="text-3xl drop-shadow-lg"
                    >
                      {t.icon}
                    </motion.div>
                  </div>
                  {/* Bottom caption */}
                  <div className="absolute inset-x-2 bottom-6 flex flex-col items-center gap-0.5">
                    {t.caption.map((word, wi) => (
                      <motion.span
                        key={wi}
                        initial={{ opacity: 0, y: 4 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: i * 0.07 + wi * 0.08 }}
                        className="text-[9px] sm:text-[10px] font-black uppercase leading-none tracking-wide"
                        style={{ color: wi === 1 ? t.captionColor : "white", textShadow: "0 1px 6px #000" }}
                      >
                        {word}
                      </motion.span>
                    ))}
                  </div>
                  {/* Right sidebar mini icons */}
                  <div className="absolute right-1.5 bottom-[30%] flex flex-col gap-2 items-center">
                    {["♥", "💬", "↗"].map((ic, si) => (
                      <div key={si} className="flex flex-col items-center gap-0.5">
                        <div className="w-5 h-5 rounded-full bg-white/10 border border-white/15 flex items-center justify-center text-[7px]">{ic}</div>
                        <span className="text-[6px] text-white/35">{t.stats[si]}</span>
                      </div>
                    ))}
                  </div>
                  {/* Bottom scrim */}
                  <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-black/70 to-transparent" />
                  {/* "Use Template" overlay on hover */}
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-250">
                    <Link href="/generate">
                      <motion.span
                        whileHover={{ scale: 1.06 }}
                        whileTap={{ scale: 0.96 }}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[10px] font-bold text-white border border-white/25 bg-white/10 backdrop-blur-sm hover:bg-white/20 transition-all cursor-pointer"
                        style={{ boxShadow: `0 0 12px ${t.glow}` }}
                      >
                        <Zap className="w-2.5 h-2.5" fill="currentColor" />
                        Use Template
                      </motion.span>
                    </Link>
                  </div>
                </div>

                {/* Card footer */}
                <div className="p-3 flex flex-col gap-1.5">
                  {/* Category badge */}
                  <span className={`self-start text-[9px] font-bold px-2 py-0.5 rounded-full ${t.badge}`}>
                    {t.category}
                  </span>
                  {/* Title */}
                  <p className="text-[11px] sm:text-xs font-semibold text-white/80 leading-tight line-clamp-2">
                    {t.title}
                  </p>
                  {/* Views */}
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <Eye className="w-3 h-3" />
                    <span className="text-[10px] font-medium tabular-nums">{t.views} views</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* CTA row */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4, duration: 0.5 }}
            className="flex justify-center mt-10"
          >
            <Link href="/generate">
              <span className="flex items-center gap-2 px-6 py-3 rounded-2xl border border-white/10 text-sm font-semibold text-muted-foreground hover:bg-white/5 hover:text-foreground hover:border-white/20 transition-all cursor-pointer group">
                Browse all templates
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </span>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* ── AI Reel Generator ───────────────────────────────────── */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 pointer-events-none">
          <motion.div
            animate={{ scale: [1, 1.07, 1], opacity: [0.06, 0.12, 0.06] }}
            transition={{ repeat: Infinity, duration: 6, ease: "easeInOut" }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] rounded-full bg-primary blur-[120px]"
          />
          <div
            className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage: "linear-gradient(rgba(139,92,246,0.9) 1px, transparent 1px), linear-gradient(90deg, rgba(139,92,246,0.9) 1px, transparent 1px)",
              backgroundSize: "52px 52px",
            }}
          />
        </div>

        <div className="relative max-w-5xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary/10 border border-primary/25 text-primary text-xs font-bold mb-5 tracking-wide uppercase">
              <Zap className="w-3.5 h-3.5" fill="currentColor" />
              Try It Free — No account needed
            </div>
            <h2 className="text-3xl sm:text-5xl font-black tracking-tight mb-4">
              Generate a Reel{" "}
              <span className="gradient-text">Right Now</span>
            </h2>
            <p className="text-muted-foreground text-base sm:text-lg max-w-xl mx-auto">
              Describe your idea. Pick a category. Hit generate — watch the AI build your reel in seconds.
            </p>
          </motion.div>

          {/* Generator card */}
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.65, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="relative rounded-3xl border border-white/10 bg-white/[0.025] backdrop-blur-sm p-6 sm:p-8 shadow-[0_0_60px_rgba(139,92,246,0.08)]"
          >
            {/* Card inner top glow */}
            <div className="absolute top-0 inset-x-0 h-px rounded-t-3xl bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
            <ReelGeneratorDemo />
          </motion.div>
        </div>
      </section>

      {/* ── Platform logos ──────────────────────────────────────── */}
      <section className="py-6 border-y border-white/6 bg-white/[0.015]">
        <div className="max-w-4xl mx-auto px-4">
          <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4">
            <span className="text-[10px] text-muted-foreground/40 uppercase tracking-[0.18em] font-bold shrink-0 w-full sm:w-auto text-center mb-1 sm:mb-0">
              Publish directly to
            </span>
            {PLATFORMS.map((p) => (
              <motion.span
                key={p.label}
                whileHover={{ scale: 1.06, y: -1 }}
                whileTap={{ scale: 0.97 }}
                className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl ${p.bg} border ${p.border} ${p.text} text-xs font-bold cursor-default transition-shadow hover:shadow-[0_0_12px_rgba(255,255,255,0.06)]`}
              >
                <span className="text-base leading-none">{p.emoji}</span>
                {p.label}
              </motion.span>
            ))}
          </div>
        </div>
      </section>

      {/* ── Creator activity ticker ─────────────────────────────── */}
      <section className="py-3 overflow-hidden border-b border-primary/8 bg-primary/[0.025]">
        <div className="flex animate-ticker whitespace-nowrap" style={{ animationDuration: "38s" }}>
          {[...ACTIVITY_ITEMS, ...ACTIVITY_ITEMS, ...ACTIVITY_ITEMS, ...ACTIVITY_ITEMS].map((item, i) => (
            <div key={i} className="inline-flex items-center gap-2 mx-7 shrink-0">
              <span className="text-sm">{item.emoji}</span>
              <span className="text-xs font-bold text-primary">{item.user}</span>
              <span className="text-xs text-muted-foreground/65">{item.action}</span>
              <span className="text-muted-foreground/20 ml-5">·</span>
            </div>
          ))}
        </div>
      </section>

      {/* ── Stats ticker ────────────────────────────────────────── */}
      <section className="py-4 overflow-hidden border-b border-white/5">
        <div className="flex animate-ticker whitespace-nowrap">
          {[...STATS, ...STATS, ...STATS].map((s, i) => (
            <div key={i} className="inline-flex items-center gap-3 mx-10 shrink-0">
              <div className="w-7 h-7 rounded-xl bg-primary/12 border border-primary/20 flex items-center justify-center">
                <s.icon className="w-3.5 h-3.5 text-primary" />
              </div>
              <span className="font-black text-base text-foreground">{s.value}</span>
              <span className="text-xs text-muted-foreground">{s.label}</span>
              <span className="text-muted-foreground/20 ml-6">·</span>
            </div>
          ))}
        </div>
      </section>

      {/* ── How it works ────────────────────────────────────────── */}
      <section className="py-20 sm:py-28 px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-14"
          >
            <p className="text-xs text-primary font-bold uppercase tracking-widest mb-3">How it works</p>
            <h2 className="text-3xl sm:text-5xl font-black mb-3 tracking-tight">
              From idea to viral in{" "}
              <span className="gradient-text">3 steps</span>
            </h2>
            <p className="text-muted-foreground text-base sm:text-lg max-w-md mx-auto">
              No editing software. No learning curve. Just results.
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-3 gap-4 sm:gap-6 relative">
            {/* Connector line (desktop) */}
            <div className="hidden sm:block absolute top-10 left-[calc(16.67%+1rem)] right-[calc(16.67%+1rem)] h-px bg-gradient-to-r from-transparent via-primary/25 to-transparent pointer-events-none" />

            {STEPS.map((step, i) => (
              <motion.div
                key={step.n}
                initial={{ opacity: 0, y: 32 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.12, duration: 0.5 }}
                className="relative glass-card-elevated rounded-2xl sm:rounded-3xl p-6 sm:p-7 text-center group hover:border-primary/25 transition-all duration-300"
              >
                {/* Step number */}
                <div className="inline-flex items-center justify-center w-11 h-11 rounded-2xl bg-primary/10 border border-primary/25 mb-5 mx-auto group-hover:bg-primary/20 group-hover:neon-glow-sm transition-all duration-300">
                  <step.icon className="w-5 h-5 text-primary" />
                </div>
                <div className="absolute top-5 right-5 text-[11px] font-black text-muted-foreground/30 tabular-nums">{step.n}</div>
                <h3 className="font-bold text-base sm:text-lg mb-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{step.desc}</p>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="text-center mt-10"
          >
            <Link href="/generate">
              <span className="inline-flex items-center gap-2 text-primary font-semibold text-sm hover:gap-3 transition-all cursor-pointer group">
                Try it now — free
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </span>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* ── Style cards ─────────────────────────────────────────── */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-white/[0.015]">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <p className="text-xs text-primary font-bold uppercase tracking-widest mb-3">Visual styles</p>
            <h2 className="text-3xl sm:text-5xl font-black mb-3 tracking-tight">Three aesthetics.
              <span className="gradient-text"> Infinite</span> stories.
            </h2>
            <p className="text-muted-foreground text-base sm:text-lg">Each style is fine-tuned with its own scenes, captions, and music.</p>
          </motion.div>

          <div
            ref={scrollRef}
            className="flex md:grid md:grid-cols-3 gap-4 overflow-x-auto snap-x-mandatory pb-3 md:pb-0 -mx-4 px-4 md:mx-0 md:px-0 scrollbar-none"
            style={{ scrollbarWidth: "none" }}
          >
            {STYLES.map((style, i) => (
              <motion.div
                key={style.id}
                initial={{ opacity: 0, y: 32 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.55 }}
                className="snap-start shrink-0 w-[78vw] sm:w-[60vw] md:w-auto"
              >
                <Link href="/generate">
                  <div
                    className={`relative glass-card-elevated rounded-3xl overflow-hidden cursor-pointer group border ${style.border} transition-all duration-300 hover:shadow-2xl ${style.glow}`}
                    data-testid={`card-style-${style.id}`}
                  >
                    {/* Top accent line */}
                    <div className={`h-px w-full bg-gradient-to-r ${style.gradient} opacity-60`} />

                    {/* Phone preview */}
                    <div className="p-4 pb-2">
                      <div className="mx-auto" style={{ maxWidth: 120 }}>
                        <StylePhone style={style} />
                      </div>
                    </div>

                    {/* Info */}
                    <div className="px-5 pb-5 pt-2">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{style.icon}</span>
                          <h3 className="font-bold text-base">{style.label}</h3>
                        </div>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${style.tagColor}`}>
                          {style.tag}
                        </span>
                      </div>
                      <p className="text-muted-foreground text-xs leading-relaxed mb-4">{style.desc}</p>
                      <div className="flex items-center gap-1.5 text-primary text-xs font-semibold group-hover:gap-2.5 transition-all duration-200">
                        Create with this style <ArrowRight className="w-3.5 h-3.5" />
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>

          <div className="flex md:hidden justify-center gap-1.5 mt-5">
            {STYLES.map((_, i) => (
              <div key={i} className={`rounded-full transition-all ${i === 0 ? "w-5 h-1.5 bg-primary" : "w-1.5 h-1.5 bg-white/20"}`} />
            ))}
          </div>
        </div>
      </section>

      {/* ── Example Reels ───────────────────────────────────────── */}
      <section id="examples" className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <p className="text-xs text-primary font-bold uppercase tracking-widest mb-3">Real results</p>
            <h2 className="text-3xl sm:text-5xl font-black mb-3 tracking-tight">Made with ReelForge</h2>
            <p className="text-muted-foreground text-base sm:text-lg">Real reels, real creators, real impact.</p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-3 lg:grid-cols-6 gap-2 sm:gap-3"
          >
            {examplesLoading
              ? Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="aspect-[9/16] rounded-2xl shimmer-bar" />
                ))
              : examples?.map((reel) => (
                  <motion.div
                    key={reel.id}
                    variants={itemVariants}
                    className="group relative aspect-[9/16] rounded-2xl overflow-hidden cursor-pointer"
                    data-testid={`card-example-reel-${reel.id}`}
                  >
                    <img
                      src={reel.thumbnailUrl}
                      alt={reel.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className={`absolute inset-0 bg-gradient-to-t ${STYLE_BG[reel.style] ?? "from-black/80 to-transparent"} opacity-70 group-hover:opacity-90 transition-opacity`} />
                    <div className="absolute inset-0 flex flex-col justify-end p-2 sm:p-2.5">
                      <p className="text-white font-semibold text-[9px] sm:text-[11px] leading-tight line-clamp-2">{reel.title}</p>
                      <div className="flex items-center gap-1 mt-1">
                        <Eye className="w-2.5 h-2.5 text-white/50" />
                        <span className="text-white/50 text-[8px] sm:text-[10px]">{(reel.views / 1000).toFixed(0)}K</span>
                      </div>
                    </div>
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                      <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-full bg-white/20 backdrop-blur-md border border-white/30 flex items-center justify-center">
                        <Play className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white ml-0.5" fill="white" />
                      </div>
                    </div>
                  </motion.div>
                ))}
          </motion.div>
        </div>
      </section>

      {/* ── Testimonials ────────────────────────────────────────── */}
      <section className="relative py-24 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-primary/6 rounded-full blur-[110px]" />
          <div className="absolute top-0 left-0 w-[300px] h-[300px] bg-pink-600/5 rounded-full blur-[90px]" />
          <div className="absolute bottom-0 right-0 w-[300px] h-[300px] bg-cyan-500/5 rounded-full blur-[90px]" />
        </div>

        <div className="relative max-w-6xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 22 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="text-center mb-14"
          >
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-yellow-500/10 border border-yellow-500/25 text-yellow-400 text-xs font-bold mb-5 tracking-wide uppercase">
              <Star className="w-3.5 h-3.5 fill-yellow-400" />
              180K+ Creators Can't Be Wrong
            </div>
            <h2 className="text-3xl sm:text-5xl font-black tracking-tight mb-4">
              Real Creators.{" "}
              <span className="gradient-text">Real Results.</span>
            </h2>
            <p className="text-muted-foreground text-base sm:text-lg max-w-xl mx-auto">
              From first reel to viral content — see what creators are saying.
            </p>
          </motion.div>

          {/* 2×2 cards grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 lg:gap-6">
            {TESTIMONIALS.map((t, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 36, scale: 0.95 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.55, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] }}
                animate={{ y: [0, i % 2 === 0 ? -7 : -10, 0] }}
                // @ts-ignore — Framer Motion allows combining whileInView + animate
                transition={{ y: { repeat: Infinity, duration: 4 + i * 0.7, ease: "easeInOut", delay: i * 0.5 } }}
                whileHover={{ scale: 1.025, transition: { duration: 0.22 } }}
                className={`group relative flex flex-col rounded-3xl border ${t.border} bg-white/[0.035] backdrop-blur-sm p-6 sm:p-7 transition-colors duration-300`}
              >
                {/* Neon glow on hover */}
                <div
                  className="absolute inset-0 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-400 pointer-events-none"
                  style={{ boxShadow: `0 0 32px 4px ${t.glow}, inset 0 0 24px 0 ${t.glow}18` }}
                />
                {/* Top shimmer */}
                <div
                  className="absolute top-0 inset-x-6 h-px rounded-t-3xl transition-all duration-300"
                  style={{ background: `linear-gradient(90deg, transparent, ${t.accent}55, transparent)` }}
                />

                {/* Stars + platform */}
                <div className="flex items-center justify-between mb-5">
                  <div className="flex gap-0.5">
                    {Array.from({ length: t.stars }).map((_, s) => (
                      <Star key={s} className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <span
                    className="text-[10px] font-bold px-2.5 py-1 rounded-full border"
                    style={{ color: t.accent, borderColor: `${t.accent}35`, background: `${t.accent}10` }}
                  >
                    {t.platform}
                  </span>
                </div>

                {/* Quote */}
                <p className="text-sm sm:text-[15px] text-white/80 leading-relaxed flex-1 mb-6">
                  "{t.text}"
                </p>

                {/* Divider */}
                <div className="h-px bg-white/6 mb-5" />

                {/* Author row */}
                <div className="flex items-center gap-3">
                  {/* Avatar */}
                  <div className="relative shrink-0">
                    <div
                      className={`w-11 h-11 rounded-full bg-gradient-to-br ${t.avatarGrad} flex items-center justify-center text-xs font-black text-white`}
                    >
                      {t.avatar}
                    </div>
                    {/* Verified dot */}
                    <div
                      className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full border-2 border-[#0b0b12] flex items-center justify-center"
                      style={{ background: t.accent }}
                    >
                      <span className="text-[7px] font-black text-black">✓</span>
                    </div>
                  </div>

                  {/* Name + handle */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm font-bold text-foreground truncate">{t.name}</span>
                    </div>
                    <div className="text-[11px] text-muted-foreground truncate">{t.handle}</div>
                  </div>

                  {/* Followers */}
                  <div className="shrink-0 text-right">
                    <div className="text-sm font-black" style={{ color: t.accent }}>{t.followers}</div>
                    <div className="text-[10px] text-white/30">followers</div>
                  </div>
                </div>

                {/* Category pill */}
                <div className="mt-4 flex items-center gap-2">
                  <span
                    className="text-[10px] font-bold px-2.5 py-1 rounded-full"
                    style={{ color: t.accent, background: `${t.accent}12`, border: `1px solid ${t.accent}28` }}
                  >
                    {t.category} creator
                  </span>
                  <span className="text-[10px] text-white/25">using ReelForge</span>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Bottom trust strip */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5 }}
            className="flex flex-wrap items-center justify-center gap-6 mt-12 text-sm text-muted-foreground/50"
          >
            {[
              ["⭐", "4.9 / 5 average rating"],
              ["🎬", "2.4M+ reels created"],
              ["🌍", "180K+ active creators"],
            ].map(([icon, label], i) => (
              <span key={i} className="flex items-center gap-2 font-medium">
                <span>{icon}</span> {label}
              </span>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── Features ────────────────────────────────────────────── */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass-card-elevated rounded-3xl sm:rounded-[2rem] p-8 sm:p-12 relative overflow-hidden"
          >
            {/* Glow */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 pointer-events-none" />
            <div className="relative">
              <p className="text-xs text-primary font-bold uppercase tracking-widest mb-3 text-center">What you get</p>
              <h2 className="text-2xl sm:text-4xl font-black text-center mb-10">
                Everything you need.{" "}
                <span className="gradient-text">Nothing you don't.</span>
              </h2>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                {FEATURES_BENTO.map((feat, i) => (
                  <motion.div
                    key={feat.title}
                    initial={{ opacity: 0, y: 16 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.08 }}
                    whileHover={{ scale: 1.025, transition: { duration: 0.18 } }}
                    className={`relative group rounded-2xl p-5 border ${feat.border} ${feat.bg} overflow-hidden cursor-default`}
                  >
                    <div
                      className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none rounded-2xl"
                      style={{ boxShadow: `inset 0 0 28px ${feat.glow}` }}
                    />
                    <div className={`w-9 h-9 rounded-xl ${feat.bg} border ${feat.border} flex items-center justify-center mb-3.5 relative z-10`}>
                      <feat.icon className={`w-4 h-4 ${feat.color}`} />
                    </div>
                    <h3 className="font-bold text-sm text-foreground mb-1.5 relative z-10">{feat.title}</h3>
                    <p className="text-xs text-muted-foreground leading-relaxed relative z-10">{feat.desc}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── Pricing ──────────────────────────────────────────────── */}
      <section className="relative py-24 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 pointer-events-none">
          <motion.div
            animate={{ scale: [1, 1.08, 1], opacity: [0.05, 0.11, 0.05] }}
            transition={{ repeat: Infinity, duration: 7, ease: "easeInOut" }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[500px] rounded-full bg-violet-600 blur-[130px]"
          />
          <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-pink-600/6 rounded-full blur-[100px]" />
          <div className="absolute bottom-0 left-0 w-[350px] h-[350px] bg-cyan-500/6 rounded-full blur-[100px]" />
          <div
            className="absolute inset-0 opacity-[0.028]"
            style={{
              backgroundImage: "linear-gradient(rgba(139,92,246,0.9) 1px, transparent 1px), linear-gradient(90deg, rgba(139,92,246,0.9) 1px, transparent 1px)",
              backgroundSize: "52px 52px",
            }}
          />
        </div>

        <div className="relative max-w-6xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 22 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="text-center mb-14"
          >
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary/10 border border-primary/25 text-primary text-xs font-bold mb-5 tracking-wide uppercase">
              <Sparkles className="w-3.5 h-3.5" />
              Simple Pricing
            </div>
            <h2 className="text-3xl sm:text-5xl font-black tracking-tight mb-4">
              Pick Your{" "}
              <span className="gradient-text">Creator Plan</span>
            </h2>
            <p className="text-muted-foreground text-base sm:text-lg max-w-xl mx-auto">
              Start free and scale as you grow. No hidden fees, cancel anytime.
            </p>
          </motion.div>

          {/* Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 lg:gap-6 items-stretch">

            {/* ── Free ── */}
            <motion.div
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.55, delay: 0, ease: [0.22, 1, 0.36, 1] }}
              whileHover={{ y: -6, transition: { duration: 0.25 } }}
              className="group relative flex flex-col rounded-3xl border border-white/8 bg-white/[0.03] backdrop-blur-sm p-7 hover:border-white/18 transition-all duration-300 hover:shadow-[0_0_30px_rgba(255,255,255,0.04)]"
            >
              <div className="absolute top-0 inset-x-0 h-px rounded-t-3xl bg-gradient-to-r from-transparent via-white/15 to-transparent" />
              <div className="mb-6">
                <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-lg bg-white/5 border border-white/8 text-xs font-bold text-white/50 mb-4">
                  🆓 Free
                </div>
                <div className="flex items-end gap-1 mb-2">
                  <span className="text-5xl font-black text-foreground">$0</span>
                  <span className="text-muted-foreground text-sm mb-2">/month</span>
                </div>
                <p className="text-sm text-muted-foreground">Perfect to try it out. No credit card needed.</p>
              </div>
              <ul className="flex flex-col gap-3 mb-8 flex-1">
                {[
                  ["3 reels per month",          true],
                  ["720p export quality",         true],
                  ["3 base styles",               true],
                  ["Watermarked videos",          true],
                  ["Community support",           true],
                  ["Custom music",               false],
                  ["Remove watermark",           false],
                  ["Priority support",           false],
                ].map(([feat, included], i) => (
                  <li key={i} className="flex items-center gap-2.5 text-sm">
                    <span className={`shrink-0 w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-black ${included ? "bg-white/10 text-white/70" : "bg-white/3 text-white/20"}`}>
                      {included ? "✓" : "×"}
                    </span>
                    <span className={included ? "text-white/70" : "text-white/25 line-through"}>{feat as string}</span>
                  </li>
                ))}
              </ul>
              <Link href="/register">
                <span className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl border border-white/12 text-sm font-bold text-muted-foreground hover:bg-white/5 hover:text-foreground hover:border-white/22 transition-all cursor-pointer">
                  Start Free
                </span>
              </Link>
            </motion.div>

            {/* ── Creator Pro ── (highlighted) */}
            <motion.div
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.55, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
              whileHover={{ y: -8, transition: { duration: 0.25 } }}
              className="group relative flex flex-col rounded-3xl p-7 md:-mt-4 md:mb-0 transition-all duration-300"
            >
              {/* Animated gradient border */}
              <div className="absolute inset-0 rounded-3xl bg-gradient-to-b from-violet-500/50 via-primary/30 to-pink-500/25 opacity-70 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="absolute inset-px rounded-3xl bg-[#0e0a1f]" />
              {/* Neon outer glow */}
              <div className="absolute inset-0 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" style={{ boxShadow: "0 0 40px 4px rgba(139,92,246,0.3), 0 0 80px 8px rgba(139,92,246,0.12)" }} />
              {/* Top shimmer line */}
              <div className="absolute top-0 inset-x-4 h-px rounded-t-3xl bg-gradient-to-r from-transparent via-violet-400/70 to-transparent" />

              <div className="relative flex flex-col flex-1">
                {/* Badge */}
                <div className="absolute -top-10 left-1/2 -translate-x-1/2 md:static md:translate-x-0 md:top-auto md:left-auto mb-4 flex justify-center">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary text-primary-foreground text-[11px] font-black tracking-wide neon-glow">
                    ⚡ Most Popular
                  </span>
                </div>

                <div className="mb-6">
                  <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-lg bg-primary/15 border border-primary/25 text-xs font-bold text-primary mb-4">
                    🚀 Creator Pro
                  </div>
                  <div className="flex items-end gap-1 mb-2">
                    <span className="text-5xl font-black gradient-text">$12</span>
                    <span className="text-muted-foreground text-sm mb-2">/month</span>
                  </div>
                  <p className="text-sm text-muted-foreground">For creators who post daily and want to go viral.</p>
                </div>

                <ul className="flex flex-col gap-3 mb-8 flex-1">
                  {[
                    "50 reels per month",
                    "1080p HD export",
                    "All 6 styles",
                    "No watermark",
                    "Custom music upload",
                    "Caption editor",
                    "Priority support",
                    "Analytics dashboard",
                  ].map((feat, i) => (
                    <li key={i} className="flex items-center gap-2.5 text-sm">
                      <span className="shrink-0 w-4 h-4 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center text-[10px] font-black text-primary">✓</span>
                      <span className="text-white/80">{feat}</span>
                    </li>
                  ))}
                </ul>

                <Link href="/register">
                  <motion.span
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.97 }}
                    className="relative w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-primary text-primary-foreground text-sm font-bold neon-glow overflow-hidden cursor-pointer group/btn"
                  >
                    <span className="absolute inset-0 -translate-x-full group-hover/btn:translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent transition-transform duration-500" />
                    <Zap className="w-4 h-4 relative z-10" fill="currentColor" />
                    <span className="relative z-10">Get Creator Pro</span>
                  </motion.span>
                </Link>
              </div>
            </motion.div>

            {/* ── Studio Max ── */}
            <motion.div
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.55, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
              whileHover={{ y: -6, transition: { duration: 0.25 } }}
              className="group relative flex flex-col rounded-3xl border border-white/8 bg-white/[0.03] backdrop-blur-sm p-7 hover:border-cyan-500/30 transition-all duration-300 hover:shadow-[0_0_30px_rgba(6,182,212,0.07)]"
            >
              <div className="absolute top-0 inset-x-0 h-px rounded-t-3xl bg-gradient-to-r from-transparent via-cyan-400/20 to-transparent group-hover:via-cyan-400/50 transition-all duration-300" />
              <div className="absolute inset-0 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" style={{ boxShadow: "0 0 30px 2px rgba(6,182,212,0.12)" }} />

              <div className="mb-6">
                <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-xs font-bold text-cyan-400 mb-4">
                  👑 Studio Max
                </div>
                <div className="flex items-end gap-1 mb-2">
                  <span className="text-5xl font-black text-foreground">$29</span>
                  <span className="text-muted-foreground text-sm mb-2">/month</span>
                </div>
                <p className="text-sm text-muted-foreground">For agencies and power creators at scale.</p>
              </div>

              <ul className="flex flex-col gap-3 mb-8 flex-1">
                {[
                  "Unlimited reels",
                  "4K export quality",
                  "All styles + custom",
                  "No watermark",
                  "Custom music library",
                  "Advanced caption editor",
                  "24/7 priority support",
                  "Team workspace (5 seats)",
                  "API access",
                  "White-label exports",
                ].map((feat, i) => (
                  <li key={i} className="flex items-center gap-2.5 text-sm">
                    <span className="shrink-0 w-4 h-4 rounded-full bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-[10px] font-black text-cyan-400">✓</span>
                    <span className="text-white/70">{feat}</span>
                  </li>
                ))}
              </ul>

              <Link href="/register">
                <span className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl border border-cyan-500/25 bg-cyan-500/8 text-sm font-bold text-cyan-300 hover:bg-cyan-500/15 hover:border-cyan-500/45 transition-all cursor-pointer group-hover:shadow-[0_0_16px_rgba(6,182,212,0.2)]">
                  <Users className="w-4 h-4" />
                  Get Studio Max
                </span>
              </Link>
            </motion.div>

          </div>

          {/* Money-back note */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="text-center text-xs text-muted-foreground/50 mt-8 flex items-center justify-center gap-1.5"
          >
            <Check className="w-3.5 h-3.5 text-green-500" />
            7-day money-back guarantee · No contracts · Cancel anytime
          </motion.p>
        </div>
      </section>

      {/* ── Waitlist ─────────────────────────────────────────────── */}
      <section className="relative py-24 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 pointer-events-none">
          <motion.div
            animate={{ scale: [1, 1.12, 1], opacity: [0.07, 0.16, 0.07] }}
            transition={{ repeat: Infinity, duration: 6, ease: "easeInOut" }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] rounded-full bg-violet-600 blur-[130px]"
          />
          <motion.div
            animate={{ scale: [1, 1.1, 1], opacity: [0.05, 0.1, 0.05] }}
            transition={{ repeat: Infinity, duration: 8, ease: "easeInOut", delay: 2 }}
            className="absolute top-1/3 -left-32 w-[400px] h-[400px] rounded-full bg-cyan-500 blur-[100px]"
          />
          <motion.div
            animate={{ scale: [1, 1.1, 1], opacity: [0.05, 0.1, 0.05] }}
            transition={{ repeat: Infinity, duration: 7, ease: "easeInOut", delay: 1 }}
            className="absolute bottom-0 -right-24 w-[360px] h-[360px] rounded-full bg-pink-600 blur-[100px]"
          />
          {/* Neon grid */}
          <div
            className="absolute inset-0 opacity-[0.035]"
            style={{
              backgroundImage: "linear-gradient(rgba(139,92,246,0.9) 1px, transparent 1px), linear-gradient(90deg, rgba(139,92,246,0.9) 1px, transparent 1px)",
              backgroundSize: "52px 52px",
            }}
          />
          <div className="absolute inset-0 scan-line opacity-15" />
        </div>

        <div className="relative max-w-2xl mx-auto text-center">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: -14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary/10 border border-primary/30 text-primary text-xs font-bold mb-7 tracking-wide uppercase"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
            </span>
            Limited Early Access — Spots Filling Fast
          </motion.div>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.65, delay: 0.07, ease: [0.22, 1, 0.36, 1] }}
            className="text-4xl sm:text-6xl font-black tracking-tight leading-[1.0] mb-5"
          >
            Join{" "}
            <span className="gradient-text neon-text">Early Access</span>
          </motion.h2>

          {/* Sub */}
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, delay: 0.15 }}
            className="text-base sm:text-lg text-muted-foreground mb-10 max-w-lg mx-auto leading-relaxed"
          >
            Be first in line. Early members get <span className="text-foreground font-semibold">free Pro access</span> for life — no credit card, no catch.
          </motion.p>

          {/* Perks row */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.22 }}
            className="flex flex-wrap justify-center gap-3 mb-10"
          >
            {[
              { icon: "🚀", label: "Free Pro plan" },
              { icon: "🎬", label: "Unlimited reels" },
              { icon: "🔒", label: "No credit card" },
            ].map((perk, i) => (
              <span key={i} className="flex items-center gap-2 px-4 py-2 rounded-2xl border border-white/8 bg-white/[0.035] text-sm text-white/70 font-medium">
                <span>{perk.icon}</span> {perk.label}
              </span>
            ))}
          </motion.div>

          {/* Form */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.28, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          >
            <WaitlistForm />
          </motion.div>
        </div>
      </section>

      {/* ── CTA ─────────────────────────────────────────────────── */}
      <section className="py-24 sm:py-32 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        {/* Dramatic glow */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-primary/8 rounded-full blur-[120px]" />
          <div className="absolute top-1/2 left-1/3 -translate-y-1/2 w-[300px] h-[300px] bg-accent/6 rounded-full blur-[80px]" />
          <div className="absolute inset-0 scan-line opacity-20" />
        </div>

        <div className="max-w-3xl mx-auto text-center relative">
          <motion.div
            initial={{ opacity: 0, scale: 0.92 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55 }}
          >
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary/10 border border-primary/25 text-primary text-xs font-semibold mb-7">
              <Zap className="w-3.5 h-3.5" fill="currentColor" />
              Free forever · 3 reels / month
            </div>

            <h2 className="text-4xl sm:text-6xl lg:text-7xl font-black mb-5 tracking-tight leading-[1.0]">
              Ready to go{" "}
              <span className="gradient-text neon-text">viral?</span>
            </h2>
            <p className="text-muted-foreground text-lg sm:text-xl mb-10 max-w-lg mx-auto">
              Join 180,000+ creators making content that stops the scroll — in seconds, not hours.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/generate">
                <span
                  className="relative flex items-center gap-2.5 px-9 py-4 bg-primary text-primary-foreground rounded-2xl font-bold text-lg neon-glow hover:bg-primary/90 transition-all cursor-pointer animate-pulse-glow w-full sm:w-auto justify-center overflow-hidden group"
                  data-testid="button-cta-generate"
                >
                  <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full bg-gradient-to-r from-transparent via-white/15 to-transparent transition-transform duration-500" />
                  <Zap className="w-5 h-5 relative z-10" fill="currentColor" />
                  <span className="relative z-10">Create your first reel</span>
                </span>
              </Link>
              <Link href="/pricing">
                <span className="flex items-center gap-2 px-6 py-4 text-muted-foreground hover:text-foreground transition-colors cursor-pointer text-sm font-medium w-full sm:w-auto justify-center">
                  Compare plans <ChevronRight className="w-4 h-4" />
                </span>
              </Link>
            </div>

            <p className="mt-6 text-xs text-muted-foreground/60">
              No credit card required · Cancel anytime · GDPR compliant
            </p>
          </motion.div>
        </div>
      </section>

      {/* Sticky mobile CTA */}
      <StickyCTA />
    </div>
  );
}
