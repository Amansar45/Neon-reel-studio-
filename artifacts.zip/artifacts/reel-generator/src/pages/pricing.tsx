import { motion } from "framer-motion";
import { Link } from "wouter";
import { Check, X, Zap, Star, Infinity, Shield, RotateCcw } from "lucide-react";

const PLANS = [
  {
    id: "free",
    name: "Free",
    price: "0",
    period: "/month",
    desc: "Start creating. See what ReelForge can do.",
    icon: Zap,
    iconColor: "text-muted-foreground",
    iconBg: "bg-muted border-white/10",
    nameColor: "text-foreground",
    borderColor: "border-white/10",
    bgColor: "",
    ctaText: "Get Started Free",
    ctaClass: "bg-white/8 text-foreground border border-white/12 hover:bg-white/12",
    features: [
      { text: "3 reels per month",   included: true },
      { text: "Watermark on exports", included: true },
      { text: "480p resolution",      included: true },
      { text: "3 visual styles",      included: true },
      { text: "No watermark",         included: false },
      { text: "Priority rendering",   included: false },
      { text: "1080p resolution",     included: false },
      { text: "API access",           included: false },
    ],
  },
  {
    id: "pro",
    name: "Pro",
    price: "12",
    period: "/month",
    desc: "For creators who post consistently and need the edge.",
    icon: Star,
    iconColor: "text-primary",
    iconBg: "bg-primary/15 border-primary/30",
    nameColor: "text-primary",
    borderColor: "border-primary/40",
    bgColor: "bg-primary/3",
    highlighted: true,
    ctaText: "Start Pro",
    ctaClass: "bg-primary text-white neon-glow hover:bg-primary/90",
    features: [
      { text: "50 reels per month",       included: true },
      { text: "No watermark",             included: true },
      { text: "1080p resolution",         included: true },
      { text: "3 visual styles",          included: true },
      { text: "Priority rendering",       included: true },
      { text: "Background music library", included: true },
      { text: "API access",               included: false },
      { text: "Custom branding",          included: false },
    ],
  },
  {
    id: "ultra",
    name: "Ultra",
    price: "29",
    period: "/month",
    desc: "Unlimited power. For agencies and power creators.",
    icon: Infinity,
    iconColor: "text-yellow-400",
    iconBg: "bg-yellow-500/12 border-yellow-500/30",
    nameColor: "text-yellow-400",
    borderColor: "border-yellow-500/35",
    bgColor: "bg-yellow-500/3",
    ctaText: "Go Ultra",
    ctaClass: "bg-yellow-500 text-black hover:bg-yellow-400 font-black",
    features: [
      { text: "Unlimited reels",          included: true },
      { text: "No watermark",             included: true },
      { text: "4K resolution",            included: true },
      { text: "3 visual styles",          included: true },
      { text: "Priority rendering",       included: true },
      { text: "Background music library", included: true },
      { text: "Full API access",          included: true },
      { text: "Custom branding",          included: true },
    ],
  },
];

const TRUST = [
  { icon: Shield,    label: "SSL Encrypted" },
  { icon: RotateCcw, label: "Cancel Anytime" },
  { icon: Star,      label: "7-Day Free Trial" },
];

const containerVariants = {
  hidden:  { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
};
const itemVariants = {
  hidden:  { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-background pt-16">

      {/* Bg orbs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-24 left-1/2 -translate-x-1/2 w-[min(600px,90vw)] h-[260px] bg-primary/6 rounded-full blur-[100px]" />
      </div>

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -16 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12 sm:mb-16"
        >
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary/10 border border-primary/25 text-primary text-xs sm:text-sm font-medium mb-6">
            Simple, honest pricing
          </div>
          <h1 className="text-3xl sm:text-6xl font-black gradient-text neon-text mb-4">
            Build your audience
          </h1>
          <p className="text-muted-foreground text-sm sm:text-lg max-w-xl mx-auto">
            Start free. Upgrade when you're ready to take your content to the next level.
          </p>
        </motion.div>

        {/* Trust badges */}
        <div className="flex items-center justify-center gap-6 sm:gap-10 mb-10 flex-wrap">
          {TRUST.map((t) => (
            <div key={t.label} className="flex items-center gap-2 text-muted-foreground text-xs sm:text-sm">
              <t.icon className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-primary/70" />
              {t.label}
            </div>
          ))}
        </div>

        {/* Plans — vertical stack on mobile, 3-col on md+ */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="flex flex-col md:grid md:grid-cols-3 gap-4 sm:gap-5"
        >
          {PLANS.map((plan) => (
            <motion.div
              key={plan.id}
              variants={itemVariants}
              className={`relative glass-card-elevated rounded-2xl sm:rounded-3xl border ${plan.borderColor} ${plan.bgColor} flex flex-col overflow-hidden`}
              data-testid={`card-plan-${plan.id}`}
            >
              {/* Top accent line */}
              {plan.highlighted && (
                <div className="h-0.5 w-full bg-gradient-to-r from-transparent via-primary to-transparent" />
              )}

              {/* Popular badge */}
              {plan.highlighted && (
                <div className="absolute top-4 right-4 px-2.5 py-1 rounded-full bg-primary/20 border border-primary/35 text-primary text-[10px] font-black tracking-widest uppercase">
                  Popular
                </div>
              )}

              {/* Mobile: horizontal layout for header */}
              <div className="p-5 sm:p-7">
                <div className="flex items-start gap-3 sm:block mb-4 sm:mb-5">
                  <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-2xl border flex items-center justify-center shrink-0 ${plan.iconBg}`}>
                    <plan.icon className={`w-5 h-5 sm:w-6 sm:h-6 ${plan.iconColor}`} />
                  </div>
                  <div className="sm:mt-4 flex-1">
                    <h2 className={`text-xl sm:text-2xl font-black ${plan.nameColor}`}>{plan.name}</h2>
                    <div className="flex items-baseline gap-1 mt-0.5 sm:mt-1">
                      <span className="text-3xl sm:text-4xl font-black text-foreground">${plan.price}</span>
                      <span className="text-muted-foreground text-sm">{plan.period}</span>
                    </div>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed mb-5 sm:mb-6">{plan.desc}</p>

                {/* Features */}
                <div className="space-y-2.5 sm:space-y-3 mb-6 sm:mb-8">
                  {plan.features.map((f) => (
                    <div key={f.text} className="flex items-center gap-3">
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${
                        f.included ? "bg-primary/15 border border-primary/30" : "bg-white/4"
                      }`}>
                        {f.included
                          ? <Check className="w-3 h-3 text-primary" />
                          : <X className="w-2.5 h-2.5 text-muted-foreground/40" />
                        }
                      </div>
                      <span className={`text-sm leading-tight ${f.included ? "text-foreground" : "text-muted-foreground/50"}`}>
                        {f.text}
                      </span>
                    </div>
                  ))}
                </div>

                <Link href="/register">
                  <span
                    className={`block w-full py-3.5 rounded-2xl text-center font-bold text-sm transition-all cursor-pointer active:scale-[0.98] ${plan.ctaClass}`}
                    data-testid={`button-plan-cta-${plan.id}`}
                  >
                    {plan.ctaText}
                  </span>
                </Link>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Bottom note */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mt-10 text-sm text-muted-foreground"
        >
          No contracts. Cancel anytime. All paid plans include a 7-day free trial.
        </motion.p>
      </div>
    </div>
  );
}
