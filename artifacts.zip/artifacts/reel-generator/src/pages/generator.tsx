import { useState, useCallback, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Zap, Music, ImageIcon, Download, CheckCircle,
  AlertCircle, Loader2, ChevronDown, ChevronUp,
} from "lucide-react";
import { useGenerateReel, useGetReelJob, getGetReelJobQueryKey, useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { CaptionOverlay } from "../components/CaptionOverlay";
import { ImageUploadZone } from "../components/ImageUploadZone";

const STYLES = [
  {
    id: "sigma",
    label: "Sigma",
    emoji: "⚡",
    desc: "Stoic. Ruthless. Dominant.",
    gradient: "from-slate-600 to-slate-800",
    border: "border-slate-500/40",
    selectedBorder: "border-slate-300",
    glow: "shadow-slate-400/25",
    activeBg: "bg-slate-500/10",
  },
  {
    id: "anime_motivation",
    label: "Anime Motivation",
    emoji: "🔥",
    desc: "High-energy. Vibrant. Unstoppable.",
    gradient: "from-pink-600 to-purple-800",
    border: "border-pink-500/40",
    selectedBorder: "border-pink-400",
    glow: "shadow-pink-500/30",
    activeBg: "bg-pink-500/10",
  },
  {
    id: "sad_aesthetic",
    label: "Sad Aesthetic",
    emoji: "🌧",
    desc: "Melancholic. Lo-fi. Emotional.",
    gradient: "from-blue-600 to-indigo-800",
    border: "border-blue-400/40",
    selectedBorder: "border-blue-300",
    glow: "shadow-blue-400/30",
    activeBg: "bg-blue-400/10",
  },
];

const MUSIC_STYLES = [
  { id: "epic",         label: "Epic",         emoji: "🎸" },
  { id: "lofi",         label: "Lo-Fi",         emoji: "🎵" },
  { id: "dark_ambient", label: "Dark Ambient",  emoji: "🌑" },
  { id: "upbeat",       label: "Upbeat",        emoji: "⚡" },
];

const EXAMPLE_PROMPTS = [
  "A lone wolf building his empire in silence",
  "Never give up, even when it hurts the most",
  "Missing someone at 3am while the city sleeps",
];

export default function GeneratorPage() {
  const [prompt, setPrompt] = useState("");
  const [selectedStyle, setSelectedStyle] = useState("sigma");
  const [selectedMusic, setSelectedMusic] = useState("epic");
  const [uploadedImages, setUploadedImages] = useState<File[]>([]);
  const [currentJobId, setCurrentJobId] = useState<string | null>(null);
  const [showUpload, setShowUpload] = useState(false);
  const [pageIsDragging, setPageIsDragging] = useState(false);
  const uploadSectionRef = useRef<HTMLDivElement>(null);
  const dragCountRef = useRef(0);

  const token = typeof window !== "undefined" ? localStorage.getItem("rf_token") : null;
  const { data: me } = useGetMe({ query: { enabled: !!token, queryKey: getGetMeQueryKey() } });
  const isPro = me?.plan === "pro" || me?.plan === "ultra";

  const generateMutation = useGenerateReel();

  const { data: jobData } = useGetReelJob(currentJobId ?? "", {
    query: {
      enabled: !!currentJobId,
      queryKey: getGetReelJobQueryKey(currentJobId ?? ""),
      refetchInterval: (query) => {
        const data = query.state.data;
        if (data?.status === "completed" || data?.status === "failed") return false;
        return 2000;
      },
    },
  });

  const handleGenerate = () => {
    if (!prompt.trim()) return;
    generateMutation.mutate(
      {
        data: {
          prompt: prompt.trim(),
          style: selectedStyle as "sigma" | "anime_motivation" | "sad_aesthetic",
          musicStyle: selectedMusic as "epic" | "lofi" | "dark_ambient" | "upbeat",
          hasWatermark: !isPro,
        },
      },
      { onSuccess: (job) => setCurrentJobId(job.id) }
    );
  };

  // Page-level drag detection — highlights the upload zone wherever the user
  // drops a file on the page, not just on the specific dropzone element.
  useEffect(() => {
    const onDragEnter = (e: DragEvent) => {
      if (!e.dataTransfer?.types.includes("Files")) return;
      dragCountRef.current += 1;
      if (dragCountRef.current === 1) {
        setPageIsDragging(true);
        setShowUpload(true);
        // Scroll upload zone into view after a tick so the panel can expand
        setTimeout(() => uploadSectionRef.current?.scrollIntoView({ behavior: "smooth", block: "center" }), 80);
      }
    };
    const onDragLeave = () => {
      dragCountRef.current = Math.max(0, dragCountRef.current - 1);
      if (dragCountRef.current === 0) setPageIsDragging(false);
    };
    const onDrop = () => {
      dragCountRef.current = 0;
      setPageIsDragging(false);
    };

    document.addEventListener("dragenter", onDragEnter);
    document.addEventListener("dragleave", onDragLeave);
    document.addEventListener("drop", onDrop);
    return () => {
      document.removeEventListener("dragenter", onDragEnter);
      document.removeEventListener("dragleave", onDragLeave);
      document.removeEventListener("drop", onDrop);
    };
  }, []);

  const isGenerating = generateMutation.isPending
    || (!!currentJobId && (jobData?.status === "processing" || jobData?.status === "pending"));
  const isCompleted = jobData?.status === "completed";
  const isFailed    = jobData?.status === "failed";
  const progress    = jobData?.progress ?? 0;
  const statusStyle = STYLES.find((s) => s.id === selectedStyle)!;

  return (
    <div className="min-h-screen bg-background pt-16">

      {/* Page header */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-4 sm:pt-12 sm:pb-6 text-center">
        <motion.h1
          initial={{ opacity: 0, y: -16 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-3xl sm:text-5xl font-black mb-2 gradient-text neon-text"
        >
          Create Your Reel
        </motion.h1>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="text-muted-foreground text-sm sm:text-base"
        >
          Describe your vibe. We handle the rest.
        </motion.p>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pb-32 sm:pb-12">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-5 lg:gap-8">

          {/* ── Left: Controls ─────────────────── */}
          <div className="lg:col-span-3 flex flex-col gap-4 sm:gap-5">

            {/* Prompt */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.08 }}
              className="glass-card-elevated rounded-2xl sm:rounded-3xl p-4 sm:p-6"
            >
              <label className="block text-xs font-bold mb-3 text-muted-foreground uppercase tracking-widest">
                Your Vibe
              </label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Type your idea... e.g. 'A lone wolf who works while others sleep, building his empire in silence'"
                className="w-full bg-transparent resize-none text-foreground placeholder-muted-foreground text-sm sm:text-base leading-relaxed focus:outline-none min-h-[96px]"
                rows={4}
                maxLength={500}
                data-testid="input-prompt"
              />
              <div className="mt-3 flex items-center justify-between border-t border-white/6 pt-3 gap-2 flex-wrap">
                <span className={`text-xs font-mono ${prompt.length > 450 ? "text-yellow-400" : "text-muted-foreground"}`}>
                  {prompt.length}/500
                </span>
                <div className="flex gap-1.5 flex-wrap justify-end">
                  {EXAMPLE_PROMPTS.map((ex, i) => (
                    <button
                      key={i}
                      onClick={() => setPrompt(ex)}
                      className="text-xs px-2.5 py-1 rounded-lg bg-primary/10 text-primary hover:bg-primary/20 transition-all font-medium active:scale-95"
                    >
                      Try {i + 1}
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Style Selection */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.12 }}
              className="glass-card-elevated rounded-2xl sm:rounded-3xl p-4 sm:p-6"
            >
              <label className="block text-xs font-bold mb-4 text-muted-foreground uppercase tracking-widest">
                Visual Style
              </label>
              <div className="grid grid-cols-3 gap-2 sm:gap-3">
                {STYLES.map((style) => {
                  const isSelected = selectedStyle === style.id;
                  return (
                    <button
                      key={style.id}
                      onClick={() => setSelectedStyle(style.id)}
                      className={`relative rounded-xl sm:rounded-2xl p-3 sm:p-4 border transition-all text-left group active:scale-95 ${
                        isSelected
                          ? `${style.selectedBorder} shadow-lg ${style.glow} ${style.activeBg}`
                          : `${style.border} hover:bg-white/4`
                      }`}
                      data-testid={`button-style-${style.id}`}
                    >
                      {isSelected && (
                        <div className={`absolute inset-0 rounded-xl sm:rounded-2xl bg-gradient-to-br ${style.gradient} opacity-8`} />
                      )}
                      <div className="relative">
                        <div className="text-xl sm:text-2xl mb-1.5">{style.emoji}</div>
                        <div className="text-xs sm:text-sm font-bold leading-tight">{style.label}</div>
                        <div className="text-[10px] sm:text-xs text-muted-foreground mt-0.5 leading-tight hidden sm:block">{style.desc}</div>
                      </div>
                      {isSelected && (
                        <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-current" style={{ color: "hsl(var(--primary))" }} />
                      )}
                    </button>
                  );
                })}
              </div>
            </motion.div>

            {/* Music */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.16 }}
              className="glass-card-elevated rounded-2xl sm:rounded-3xl p-4 sm:p-6"
            >
              <label className="flex items-center gap-2 text-xs font-bold mb-4 text-muted-foreground uppercase tracking-widest">
                <Music className="w-3.5 h-3.5 text-primary" />
                Background Music
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {MUSIC_STYLES.map((m) => {
                  const isSelected = selectedMusic === m.id;
                  return (
                    <button
                      key={m.id}
                      onClick={() => setSelectedMusic(m.id)}
                      className={`flex items-center gap-2 py-2.5 px-3 rounded-xl text-sm font-medium border transition-all active:scale-95 ${
                        isSelected
                          ? "bg-primary/15 text-primary border-primary/45 neon-glow-sm"
                          : "border-white/8 text-muted-foreground hover:text-foreground hover:bg-white/5"
                      }`}
                      data-testid={`button-music-${m.id}`}
                    >
                      <span className="text-base">{m.emoji}</span>
                      <span className="text-xs sm:text-sm">{m.label}</span>
                    </button>
                  );
                })}
              </div>
            </motion.div>

            {/* Image Upload — collapsible on mobile, always open on desktop */}
            <motion.div
              ref={uploadSectionRef}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className={`glass-card-elevated rounded-2xl sm:rounded-3xl overflow-hidden transition-all duration-300 ${
                pageIsDragging ? "ring-1 ring-primary/40 shadow-lg shadow-primary/10" : ""
              }`}
            >
              {/* Header — tap to expand on mobile */}
              <button
                onClick={() => setShowUpload((v) => !v)}
                className="w-full flex items-center justify-between p-4 sm:p-5 sm:cursor-default"
                aria-expanded={showUpload}
              >
                <span className="flex items-center gap-2 text-xs font-bold text-muted-foreground uppercase tracking-widest">
                  <ImageIcon className="w-3.5 h-3.5 text-primary" />
                  Upload Images
                  {uploadedImages.length > 0 && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-primary/20 text-primary font-bold normal-case tracking-normal">
                      {uploadedImages.length}/5
                    </span>
                  )}
                  <span className="hidden sm:inline text-xs text-muted-foreground font-normal normal-case tracking-normal opacity-60">
                    Optional
                  </span>
                </span>
                <span className="sm:hidden text-muted-foreground">
                  {showUpload ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </span>
              </button>

              {/* Desktop: always visible */}
              <div className="hidden sm:block px-5 pb-5">
                <ImageUploadZone
                  files={uploadedImages}
                  onChange={setUploadedImages}
                  pageIsDragging={pageIsDragging}
                />
              </div>

              {/* Mobile: collapsible */}
              <div className="sm:hidden">
                <AnimatePresence initial={false}>
                  {(showUpload || pageIsDragging) && (
                    <motion.div
                      key="upload-body-mobile"
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.22 }}
                      className="overflow-hidden"
                    >
                      <div className="px-4 pb-4">
                        <ImageUploadZone
                          files={uploadedImages}
                          onChange={setUploadedImages}
                          pageIsDragging={pageIsDragging}
                        />
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>

            {/* Generate button — hidden on mobile (sticky bar below) */}
            <motion.button
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.25 }}
              onClick={handleGenerate}
              disabled={!prompt.trim() || isGenerating}
              className={`hidden sm:flex w-full py-4 rounded-2xl font-black text-lg items-center justify-center gap-3 transition-all ${
                !prompt.trim() || isGenerating
                  ? "bg-muted text-muted-foreground cursor-not-allowed"
                  : "bg-primary text-primary-foreground neon-glow hover:bg-primary/90 animate-pulse-glow"
              }`}
              data-testid="button-generate"
            >
              {isGenerating ? (
                <><Loader2 className="w-5 h-5 animate-spin" /> Generating...</>
              ) : (
                <><Zap className="w-5 h-5" fill="currentColor" /> Generate Reel</>
              )}
            </motion.button>
          </div>

          {/* ── Right: Preview ─────────────────── */}
          <div className="lg:col-span-2 order-first lg:order-last">
            <div className="lg:sticky lg:top-24">
              <div className="glass-card-elevated rounded-2xl sm:rounded-3xl p-4 sm:p-5">
                <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-4">
                  Preview
                </h3>

                {/* 9:16 Phone Frame */}
                <div className="relative mx-auto" style={{ maxWidth: 200 }}>
                  {/* Phone chrome */}
                  <div className="absolute -inset-2 rounded-[32px] border border-white/8 bg-gradient-to-b from-white/5 to-transparent pointer-events-none" />
                  <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-16 h-1 rounded-full bg-white/15 pointer-events-none" />

                  <div
                    className="relative w-full rounded-[24px] overflow-hidden border border-white/12 bg-black shadow-2xl shadow-black/50"
                    style={{ aspectRatio: "9/16" }}
                    data-testid="preview-frame"
                  >
                    {/* BG gradient */}
                    <div className={`absolute inset-0 bg-gradient-to-br ${statusStyle.gradient} opacity-75 transition-all duration-500`} />
                    <div className="absolute inset-0 scan-line opacity-60" />

                    {/* Generating */}
                    <AnimatePresence>
                      {isGenerating && (
                        <motion.div
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="absolute inset-0 flex flex-col items-center justify-center p-5"
                        >
                          <div className="relative mb-5">
                            <motion.div
                              className="w-14 h-14 rounded-full border-2 border-primary/30"
                              animate={{ scale: [1, 1.5, 1], opacity: [0.4, 0.05, 0.4] }}
                              transition={{ repeat: Infinity, duration: 1.6 }}
                            />
                            <motion.div
                              className="absolute inset-2 rounded-full border border-primary/50"
                              animate={{ scale: [1, 1.3, 1], opacity: [0.6, 0.1, 0.6] }}
                              transition={{ repeat: Infinity, duration: 1.6, delay: 0.3 }}
                            />
                            <div className="absolute inset-0 flex items-center justify-center">
                              <Loader2 className="w-6 h-6 text-primary animate-spin" />
                            </div>
                          </div>

                          <div className="w-full space-y-1.5">
                            <div className="flex justify-between text-[10px] text-white/60 mb-1">
                              <span>Rendering...</span>
                              <span className="font-mono font-bold">{progress}%</span>
                            </div>
                            <div className="w-full h-1 rounded-full bg-white/10">
                              <motion.div
                                className="h-full rounded-full bg-gradient-to-r from-primary to-accent"
                                animate={{ width: `${progress}%` }}
                                transition={{ duration: 0.6 }}
                              />
                            </div>
                          </div>

                          <p className="text-white/40 text-[10px] mt-4 text-center leading-snug">
                            Adding cinematic effects...
                          </p>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* Completed */}
                    <AnimatePresence>
                      {isCompleted && jobData?.videoUrl && (
                        <motion.div
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="absolute inset-0"
                        >
                          <video
                            src={jobData.videoUrl}
                            autoPlay loop muted playsInline
                            className="w-full h-full object-cover"
                            data-testid="video-preview"
                          />

                          {/* Cinematic caption overlay */}
                          <CaptionOverlay
                            prompt={jobData.prompt}
                            style={jobData.style}
                            playing
                          />

                          {/* Bottom scrim + watermark */}
                          <div className="absolute inset-x-0 bottom-0 h-[22%] bg-gradient-to-t from-black/80 to-transparent pointer-events-none" />
                          {jobData.hasWatermark && (
                            <div className="absolute bottom-2 inset-x-0 text-center text-[8px] text-white/30 font-medium tracking-widest uppercase pointer-events-none">
                              ReelForge
                            </div>
                          )}

                          {/* Completed badge */}
                          <div className="absolute top-2.5 right-2.5">
                            <div className="w-6 h-6 rounded-full bg-green-500/20 border border-green-400/40 flex items-center justify-center">
                              <CheckCircle className="w-3.5 h-3.5 text-green-400" />
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* Empty state */}
                    {!isGenerating && !isCompleted && !isFailed && (
                      <div className="absolute inset-0 flex flex-col items-center justify-center p-5">
                        <div className="w-12 h-12 rounded-2xl bg-white/8 border border-white/12 flex items-center justify-center mb-3">
                          <Zap className="w-6 h-6 text-white/25" />
                        </div>
                        <p className="text-white/25 text-[11px] text-center leading-snug">Your reel preview<br />will appear here</p>
                      </div>
                    )}

                    {/* Failed */}
                    {isFailed && (
                      <div className="absolute inset-0 flex flex-col items-center justify-center p-5">
                        <AlertCircle className="w-8 h-8 text-red-400 mb-2" />
                        <p className="text-white/60 text-[11px] text-center">Generation failed. Please try again.</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Download */}
                <AnimatePresence>
                  {isCompleted && jobData?.videoUrl && (
                    <motion.div
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mt-4 space-y-2"
                    >
                      <a
                        href={`/api/reels/download/${jobData.id}`}
                        download={`reelforge-${jobData.style}.mp4`}
                        className="flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-green-500/15 text-green-400 border border-green-500/30 font-bold text-sm hover:bg-green-500/25 transition-all active:scale-98"
                        data-testid="button-download"
                      >
                        <Download className="w-4 h-4" />
                        Download MP4
                      </a>
                      {jobData.hasWatermark && (
                        <p className="text-[11px] text-center text-muted-foreground">
                          Upgrade to <span className="text-primary font-semibold">Pro</span> to remove watermark
                        </p>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── Sticky bottom generate bar (mobile only) ── */}
      <div className="fixed bottom-0 left-0 right-0 z-40 sm:hidden bg-background/95 backdrop-blur-2xl border-t border-white/8 px-4 pt-3 pb-safe pb-4">
        <button
          onClick={handleGenerate}
          disabled={!prompt.trim() || isGenerating}
          className={`w-full py-4 rounded-2xl font-black text-base flex items-center justify-center gap-2.5 transition-all active:scale-[0.98] ${
            !prompt.trim() || isGenerating
              ? "bg-muted text-muted-foreground cursor-not-allowed"
              : "bg-primary text-primary-foreground neon-glow animate-pulse-glow"
          }`}
          data-testid="button-generate-mobile"
        >
          {isGenerating ? (
            <><Loader2 className="w-5 h-5 animate-spin" /> Generating...</>
          ) : (
            <><Zap className="w-5 h-5" fill="currentColor" /> Generate Reel</>
          )}
        </button>
      </div>
    </div>
  );
}
