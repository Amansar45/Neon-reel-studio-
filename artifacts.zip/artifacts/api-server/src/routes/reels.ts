import { Router, type IRouter } from "express";
import { db, reelJobsTable, exampleReelsTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { GenerateReelBody, GetReelJobParams } from "@workspace/api-zod";
import { optionalAuth } from "../lib/auth";

const router: IRouter = Router();

const STYLE_THUMBNAILS: Record<string, string> = {
  sigma:            "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&q=80",
  anime_motivation: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=400&q=80",
  sad_aesthetic:    "https://images.unsplash.com/photo-1516912481808-3406841bd33c?w=400&q=80",
};

// Style-specific sample videos from Google's public CORS-enabled CDN
const STYLE_VIDEOS: Record<string, string> = {
  sigma:            "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
  anime_motivation: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
  sad_aesthetic:    "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
};

function simulateProgress(createdAt: Date): { status: string; progress: number } {
  const elapsed = (Date.now() - createdAt.getTime()) / 1000;
  if (elapsed < 5)  return { status: "pending",    progress: 0  };
  if (elapsed < 12) return { status: "processing", progress: 20 };
  if (elapsed < 20) return { status: "processing", progress: 55 };
  if (elapsed < 28) return { status: "processing", progress: 80 };
  return               { status: "completed",  progress: 100 };
}

// ── Generate ──────────────────────────────────────────────────────────────────
router.post("/reels/generate", optionalAuth, async (req, res): Promise<void> => {
  const parsed = GenerateReelBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { prompt, style, musicStyle, hasWatermark } = parsed.data;
  const userId = req.user?.id ?? null;

  // Deduct one credit for authenticated users (stop at 0)
  if (userId !== null && req.user) {
    const newCredits = Math.max(0, req.user.creditsRemaining - 1);
    await db
      .update(usersTable)
      .set({ creditsRemaining: newCredits })
      .where(eq(usersTable.id, userId));
  }

  const [job] = await db
    .insert(reelJobsTable)
    .values({
      userId,
      prompt,
      style,
      musicStyle:   musicStyle ?? null,
      hasWatermark: hasWatermark ?? true,
      status:       "pending",
      progress:     0,
      thumbnailUrl: STYLE_THUMBNAILS[style] ?? null,
    })
    .returning();

  res.status(201).json({
    id:           String(job.id),
    status:       job.status,
    prompt:       job.prompt,
    style:        job.style,
    progress:     job.progress ?? 0,
    videoUrl:     job.videoUrl ?? null,
    thumbnailUrl: job.thumbnailUrl ?? null,
    musicStyle:   job.musicStyle ?? null,
    hasWatermark: job.hasWatermark,
    createdAt:    job.createdAt.toISOString(),
    completedAt:  job.completedAt?.toISOString() ?? null,
  });
});

// ── Poll job status ───────────────────────────────────────────────────────────
router.get("/reels/jobs/:jobId", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.jobId) ? req.params.jobId[0] : req.params.jobId;
  const params = GetReelJobParams.safeParse({ jobId: rawId });
  if (!params.success) {
    res.status(400).json({ error: "Invalid job ID" });
    return;
  }

  const id = parseInt(params.data.jobId, 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid job ID" });
    return;
  }

  const [job] = await db.select().from(reelJobsTable).where(eq(reelJobsTable.id, id));
  if (!job) {
    res.status(404).json({ error: "Job not found" });
    return;
  }

  // Already completed — return stored data directly
  if (job.status === "completed") {
    res.json({
      id:           String(job.id),
      status:       "completed",
      prompt:       job.prompt,
      style:        job.style,
      progress:     100,
      videoUrl:     job.videoUrl,
      thumbnailUrl: job.thumbnailUrl ?? null,
      musicStyle:   job.musicStyle ?? null,
      hasWatermark: job.hasWatermark,
      createdAt:    job.createdAt.toISOString(),
      completedAt:  job.completedAt?.toISOString() ?? null,
    });
    return;
  }

  const simulated = simulateProgress(job.createdAt);

  // Transition to completed — assign style-specific video URL
  if (simulated.status === "completed") {
    const videoUrl = STYLE_VIDEOS[job.style] ?? STYLE_VIDEOS["sigma"];
    const completedAt = new Date();
    await db
      .update(reelJobsTable)
      .set({ status: "completed", progress: 100, videoUrl, completedAt })
      .where(eq(reelJobsTable.id, job.id));

    res.json({
      id:           String(job.id),
      status:       "completed",
      prompt:       job.prompt,
      style:        job.style,
      progress:     100,
      videoUrl,
      thumbnailUrl: job.thumbnailUrl ?? null,
      musicStyle:   job.musicStyle ?? null,
      hasWatermark: job.hasWatermark,
      createdAt:    job.createdAt.toISOString(),
      completedAt:  completedAt.toISOString(),
    });
    return;
  }

  // Still in progress — persist updated progress
  await db
    .update(reelJobsTable)
    .set({ status: simulated.status, progress: simulated.progress })
    .where(eq(reelJobsTable.id, job.id));

  res.json({
    id:           String(job.id),
    status:       simulated.status,
    prompt:       job.prompt,
    style:        job.style,
    progress:     simulated.progress,
    videoUrl:     null,
    thumbnailUrl: job.thumbnailUrl ?? null,
    musicStyle:   job.musicStyle ?? null,
    hasWatermark: job.hasWatermark,
    createdAt:    job.createdAt.toISOString(),
    completedAt:  null,
  });
});

// ── Download proxy ────────────────────────────────────────────────────────────
// Proxies the video through our server so the browser `download` attribute
// works correctly (cross-origin direct links are silently blocked by browsers).
router.get("/reels/download/:jobId", async (req, res): Promise<void> => {
  const id = parseInt(req.params.jobId, 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid job ID" });
    return;
  }

  const [job] = await db.select().from(reelJobsTable).where(eq(reelJobsTable.id, id));
  if (!job) {
    res.status(404).json({ error: "Job not found" });
    return;
  }

  const videoUrl = job.videoUrl ?? STYLE_VIDEOS[job.style] ?? STYLE_VIDEOS["sigma"];

  let upstream: Response;
  try {
    upstream = await fetch(videoUrl, {
      headers: { "User-Agent": "ReelForge/1.0" },
    });
  } catch {
    res.status(502).json({ error: "Failed to reach video source" });
    return;
  }

  if (!upstream.ok) {
    res.status(502).json({ error: `Video source returned ${upstream.status}` });
    return;
  }

  const filename = `reelforge-${job.style}-${job.id}.mp4`;
  res.setHeader("Content-Type", "video/mp4");
  res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
  res.setHeader("Cache-Control", "private, max-age=3600");

  const contentLength = upstream.headers.get("content-length");
  if (contentLength) res.setHeader("Content-Length", contentLength);

  if (!upstream.body) {
    res.status(502).json({ error: "Empty video response" });
    return;
  }

  // Stream the body directly to the client
  const reader = upstream.body.getReader();
  req.on("close", () => reader.cancel());

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!res.writable) break;
      res.write(Buffer.from(value));
    }
    res.end();
  } catch {
    if (!res.headersSent) {
      res.status(500).json({ error: "Streaming error" });
    }
  }
});

// ── Example reels ─────────────────────────────────────────────────────────────
router.get("/reels/examples", async (_req, res): Promise<void> => {
  const examples = await db.select().from(exampleReelsTable);
  res.json(
    examples.map((e) => ({
      id:           String(e.id),
      title:        e.title,
      style:        e.style,
      thumbnailUrl: e.thumbnailUrl,
      videoUrl:     e.videoUrl ?? null,
      views:        e.views,
      caption:      e.caption ?? null,
    }))
  );
});

// ── History ───────────────────────────────────────────────────────────────────
router.get("/reels/history", optionalAuth, async (req, res): Promise<void> => {
  if (!req.user) {
    res.json([]);
    return;
  }

  const jobs = await db
    .select()
    .from(reelJobsTable)
    .where(eq(reelJobsTable.userId, req.user.id));

  res.json(
    jobs.map((j) => ({
      id:           String(j.id),
      status:       j.status,
      prompt:       j.prompt,
      style:        j.style,
      progress:     j.progress ?? 0,
      videoUrl:     j.videoUrl ?? null,
      thumbnailUrl: j.thumbnailUrl ?? null,
      musicStyle:   j.musicStyle ?? null,
      hasWatermark: j.hasWatermark,
      createdAt:    j.createdAt.toISOString(),
      completedAt:  j.completedAt?.toISOString() ?? null,
    }))
  );
});

export default router;
