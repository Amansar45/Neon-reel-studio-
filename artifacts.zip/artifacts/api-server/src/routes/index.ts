import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import reelsRouter from "./reels";
import userRouter from "./user";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(reelsRouter);
router.use(userRouter);

export default router;
