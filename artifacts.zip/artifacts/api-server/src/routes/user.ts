import { Router, type IRouter } from "express";
import { db, reelJobsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "../lib/auth";

const router: IRouter = Router();

router.get("/user/me", requireAuth, async (req, res): Promise<void> => {
  const user = req.user!;
  res.json({
    id: String(user.id),
    email: user.email,
    name: user.name,
    plan: user.plan,
    creditsRemaining: user.creditsRemaining,
    avatarUrl: user.avatarUrl ?? null,
  });
});

router.get("/user/dashboard", requireAuth, async (req, res): Promise<void> => {
  const user = req.user!;

  const allJobs = await db
    .select()
    .from(reelJobsTable)
    .where(eq(reelJobsTable.userId, user.id));

  const totalReels = allJobs.length;
  const planCredits: Record<string, number> = { free: 3, pro: 50, ultra: 999 };
  const maxCredits = planCredits[user.plan] ?? 3;
  const creditsUsed = maxCredits - user.creditsRemaining;

  const recentReels = allJobs
    .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
    .slice(0, 5)
    .map((j) => ({
      id: String(j.id),
      status: j.status,
      prompt: j.prompt,
      style: j.style,
      progress: j.progress ?? 0,
      videoUrl: j.videoUrl ?? null,
      thumbnailUrl: j.thumbnailUrl ?? null,
      musicStyle: j.musicStyle ?? null,
      hasWatermark: j.hasWatermark,
      createdAt: j.createdAt.toISOString(),
      completedAt: j.completedAt?.toISOString() ?? null,
    }));

  const styleCounts: Record<string, number> = {};
  for (const j of allJobs) {
    styleCounts[j.style] = (styleCounts[j.style] ?? 0) + 1;
  }
  const styleBreakdown = Object.entries(styleCounts).map(([style, count]) => ({ style, count }));

  res.json({
    totalReels,
    creditsRemaining: user.creditsRemaining,
    creditsUsed,
    recentReels,
    styleBreakdown,
  });
});

export default router;
